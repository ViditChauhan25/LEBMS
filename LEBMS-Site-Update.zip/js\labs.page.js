// public/js/labs.page.js: Laboratories Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout();
  if (!user) return;

  const isAdmin = user.role === 'ADMIN';
  if (isAdmin) {
    document.getElementById('adminActionGroup')?.classList.remove('d-none');
    document.querySelectorAll('.admin-col').forEach(el => el.classList.remove('d-none'));
  }

  let labModalInst = null;
  if (window.bootstrap) {
    const lEl = document.getElementById('labModal');
    if (lEl) labModalInst = new bootstrap.Modal(lEl);
  }

  let labsData = [];

  async function loadMetadata() {
    try {
      const [deptRes, usersRes] = await Promise.all([
        api.get('/api/departments'),
        api.get('/api/users?limit=100')
      ]);

      const deptSelect = document.getElementById('labDeptSelect');
      if (deptSelect && deptRes.data) {
        deptSelect.innerHTML = '<option value="">Select Department...</option>';
        deptRes.data.forEach(d => {
          const opt = document.createElement('option');
          opt.value = d.department_id;
          opt.textContent = `${d.department_code} - ${d.department_name}`;
          deptSelect.appendChild(opt);
        });
      }

      const inchargeSelect = document.getElementById('labInchargeSelect');
      if (inchargeSelect) {
        const users = (usersRes.data && usersRes.data.users) ? usersRes.data.users : (usersRes.data || []);
        const staffUsers = users.filter(u => u.role === 'STAFF' || u.role === 'ADMIN');
        inchargeSelect.innerHTML = '<option value="">None / Unassigned</option>';
        staffUsers.forEach(u => {
          const opt = document.createElement('option');
          opt.value = u.user_id;
          opt.textContent = `${u.full_name} (${u.role})`;
          inchargeSelect.appendChild(opt);
        });
      }
    } catch (err) {
      console.error('Failed to load lab metadata:', err);
    }
  }

  async function loadLabs() {
    const tbody = document.getElementById('labsTableBody');
    tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading labs...</td></tr>';

    try {
      const res = await api.get('/api/labs');
      labsData = res.data || [];

      if (labsData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">No laboratories registered.</td></tr>';
        return;
      }

      tbody.innerHTML = labsData.map(l => {
        let actionCol = '';
        if (isAdmin) {
          actionCol = `
            <td class="text-end text-nowrap">
              <button class="btn btn-sm btn-outline-primary edit-lab-btn me-1" data-id="${l.lab_id}">
                <i class="bi bi-pencil me-1"></i>Edit
              </button>
              <button class="btn btn-sm btn-outline-danger delete-lab-btn" data-id="${l.lab_id}">
                <i class="bi bi-trash"></i>
              </button>
            </td>
          `;
        }

        return `
          <tr>
            <td class="fw-bold">#${l.lab_id}</td>
            <td><span class="badge bg-light text-dark border font-monospace">${escapeHtml(l.lab_code)}</span></td>
            <td class="fw-semibold">${escapeHtml(l.lab_name)}</td>
            <td>
              <span class="badge bg-primary-subtle text-primary border">${escapeHtml(l.department_code || '')}</span>
              <small class="text-muted ms-1">${escapeHtml(l.department_name || '')}</small>
            </td>
            <td><small class="text-secondary">${escapeHtml(l.location || 'N/A')}</small></td>
            <td>
              <small class="fw-medium">${escapeHtml(l.incharge_name || 'Unassigned')}</small>
            </td>
            ${actionCol}
          </tr>
        `;
      }).join('');

      if (isAdmin) {
        document.querySelectorAll('.edit-lab-btn').forEach(btn => {
          btn.addEventListener('click', () => openEditModal(parseInt(btn.dataset.id, 10)));
        });
        document.querySelectorAll('.delete-lab-btn').forEach(btn => {
          btn.addEventListener('click', () => deleteLab(parseInt(btn.dataset.id, 10)));
        });
      }
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-danger"><i class="bi bi-exclamation-triangle me-1"></i>Failed to load labs: ${escapeHtml(err.message)}</td></tr>`;
    }
  }

  function openEditModal(id) {
    const lab = labsData.find(l => l.lab_id === id);
    if (!lab) return;

    document.getElementById('labId').value = lab.lab_id;
    document.getElementById('labCode').value = lab.lab_code;
    document.getElementById('labCode').disabled = true; // code cannot be changed
    document.getElementById('labName').value = lab.lab_name;
    document.getElementById('labDeptSelect').value = lab.department_id;
    document.getElementById('labLocation').value = lab.location || '';
    document.getElementById('labInchargeSelect').value = lab.incharge_user_id || '';

    document.getElementById('labModalTitle').textContent = `Edit Laboratory: ${lab.lab_name}`;
    document.getElementById('saveLabBtn').textContent = 'Update Laboratory';
    if (labModalInst) labModalInst.show();
  }

  const addBtn = document.getElementById('addLabBtn');
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      document.getElementById('labId').value = '';
      document.getElementById('labCode').value = '';
      document.getElementById('labCode').disabled = false;
      document.getElementById('labName').value = '';
      document.getElementById('labLocation').value = '';
      document.getElementById('labInchargeSelect').value = '';
      document.getElementById('labModalTitle').textContent = 'Add New Laboratory';
      document.getElementById('saveLabBtn').textContent = 'Save Laboratory';
    });
  }

  // Handle submit (create or update)
  const form = document.getElementById('labForm');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const labId = document.getElementById('labId').value;
      const labCode = document.getElementById('labCode').value.trim();
      const labName = document.getElementById('labName').value.trim();
      const deptId = parseInt(document.getElementById('labDeptSelect').value, 10);
      const location = document.getElementById('labLocation').value.trim();
      const inchargeId = document.getElementById('labInchargeSelect').value ? parseInt(document.getElementById('labInchargeSelect').value, 10) : null;

      try {
        if (labId) {
          // Update
          await api.put(`/api/labs/${labId}`, {
            lab_name: labName,
            department_id: deptId,
            location,
            incharge_user_id: inchargeId
          });
          showToast('Laboratory updated successfully.', 'success');
        } else {
          // Create
          await api.post('/api/labs', {
            lab_code: labCode,
            lab_name: labName,
            department_id: deptId,
            location,
            incharge_user_id: inchargeId
          });
          showToast('Laboratory created successfully.', 'success');
        }
        if (labModalInst) labModalInst.hide();
        loadLabs();
      } catch (err) {
        showToast(err.message, 'danger');
      }
    });
  }

  async function deleteLab(id) {
    if (!confirm(`Are you sure you want to delete laboratory #${id}?`)) return;
    try {
      await api.delete(`/api/labs/${id}`);
      showToast('Laboratory deleted successfully.', 'success');
      loadLabs();
    } catch (err) {
      showToast(err.message, 'danger');
    }
  }

  document.getElementById('refreshBtn')?.addEventListener('click', loadLabs);

  await loadMetadata();
  await loadLabs();
});
