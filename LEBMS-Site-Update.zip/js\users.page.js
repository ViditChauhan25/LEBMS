// public/js/users.page.js: User Accounts Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout({ requiredRoles: ['ADMIN'] });
  if (!user) return;

  let currentPage = 1;
  const limit = 10;
  let userModalInst = null;

  if (window.bootstrap) {
    const uEl = document.getElementById('userModal');
    if (uEl) userModalInst = new bootstrap.Modal(uEl);
  }

  async function loadDepartments() {
    try {
      const res = await api.get('/api/departments');
      const select = document.getElementById('userDeptSelect');
      if (select && res.data) {
        select.innerHTML = '<option value="">None / Unassigned</option>';
        res.data.forEach(d => {
          const opt = document.createElement('option');
          opt.value = d.department_id;
          opt.textContent = `${d.department_code} - ${d.department_name}`;
          select.appendChild(opt);
        });
      }
    } catch (err) {
      console.error('Failed to load departments:', err);
    }
  }

  async function loadUsers(page = 1) {
    currentPage = page;
    const tbody = document.getElementById('usersTableBody');
    tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading user accounts...</td></tr>';

    try {
      const res = await api.get('/api/users', { page: currentPage, limit });
      const data = res.data || {};
      const items = data.users || data.records || [];
      const pagination = data.pagination || { total: items.length, page: 1, totalPages: 1 };

      if (items.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted">No users found.</td></tr>';
        document.getElementById('paginationInfo').textContent = 'Showing 0 of 0 items';
        document.getElementById('paginationControls').innerHTML = '';
        return;
      }

      tbody.innerHTML = items.map(u => {
        let roleBadge = 'bg-secondary';
        if (u.role === 'ADMIN') roleBadge = 'bg-danger';
        else if (u.role === 'STAFF') roleBadge = 'bg-primary';
        else if (u.role === 'FACULTY') roleBadge = 'bg-warning text-dark';
        else if (u.role === 'STUDENT') roleBadge = 'bg-info text-dark';

        const isActive = u.is_active === 1 || u.is_active === true;
        const statusBadge = isActive
          ? '<span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Active</span>'
          : '<span class="badge bg-secondary"><i class="bi bi-slash-circle me-1"></i>Disabled</span>';

        const toggleBtnText = isActive ? 'Disable' : 'Enable';
        const toggleBtnClass = isActive ? 'btn-outline-danger' : 'btn-outline-success';

        return `
          <tr>
            <td class="fw-bold">#${u.user_id}</td>
            <td class="fw-semibold">${escapeHtml(u.full_name)}</td>
            <td><small class="text-secondary font-monospace">${escapeHtml(u.email)}</small></td>
            <td><span class="badge ${roleBadge}">${escapeHtml(u.role)}</span></td>
            <td><small>${escapeHtml(u.department_name || 'N/A')}</small></td>
            <td><small class="font-monospace">${escapeHtml(u.enrollment_no || '-')}</small></td>
            <td><small>${escapeHtml(u.phone || '-')}</small></td>
            <td>${statusBadge}</td>
            <td class="text-end">
              <button class="btn btn-sm ${toggleBtnClass} toggle-status-btn" data-id="${u.user_id}" data-active="${isActive}">
                ${toggleBtnText}
              </button>
            </td>
          </tr>
        `;
      }).join('');

      renderPagination(
        'paginationControls',
        'paginationInfo',
        pagination,
        (p) => loadUsers(p)
      );

      // Attach button listeners
      document.querySelectorAll('.toggle-status-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.id;
          const currActive = btn.dataset.active === 'true';
          toggleUserActive(id, !currActive);
        });
      });
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="9" class="text-center py-4 text-danger"><i class="bi bi-exclamation-triangle me-1"></i>Failed to load users: ${escapeHtml(err.message)}</td></tr>`;
    }
  }

  async function toggleUserActive(userId, targetActive) {
    const actionName = targetActive ? 'activate' : 'disable';
    if (!confirm(`Are you sure you want to ${actionName} user #${userId}?`)) return;

    try {
      await api.patch(`/api/users/${userId}/active`, { is_active: targetActive });
      showToast(`User account #${userId} ${actionName}d.`, 'success');
      loadUsers(currentPage);
    } catch (err) {
      showToast(err.message, 'danger');
    }
  }

  // Handle Create User
  const form = document.getElementById('userForm');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const payload = {
        full_name: document.getElementById('userFullName').value.trim(),
        email: document.getElementById('userEmail').value.trim(),
        password: document.getElementById('userPassword').value.trim(),
        role: document.getElementById('userRole').value,
        department_id: document.getElementById('userDeptSelect').value ? parseInt(document.getElementById('userDeptSelect').value, 10) : null,
        enrollment_no: document.getElementById('userEnrollment').value.trim() || null,
        phone: document.getElementById('userPhone').value.trim() || null
      };

      try {
        await api.post('/api/users', payload);
        showToast('User created successfully.', 'success');
        form.reset();
        if (userModalInst) userModalInst.hide();
        loadUsers(1);
      } catch (err) {
        showToast(err.message, 'danger');
      }
    });
  }

  document.getElementById('refreshBtn')?.addEventListener('click', () => loadUsers(currentPage));

  await loadDepartments();
  await loadUsers(1);
});
