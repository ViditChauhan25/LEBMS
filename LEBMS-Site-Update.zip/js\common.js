// public/js/common.js: Shared UI helpers (XSS-safe escaping, date formatting, badges, toasts)

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatDateTime(dtStr) {
  if (!dtStr) return 'N/A';
  return String(dtStr).replace('T', ' ').replace(/\.\d+Z$/, '');
}

function formatDate(dStr) {
  if (!dStr) return 'N/A';
  return String(dStr).split(' ')[0].split('T')[0];
}

function formatCurrency(num) {
  if (num === null || num === undefined || isNaN(num)) return '₹0.00';
  return '₹' + Number(num).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function renderStatusBadge(status) {
  if (!status) return '';
  const key = String(status).toLowerCase();
  const cls = `badge-status-${key}`;
  return `<span class="badge ${cls}">${escapeHtml(status)}</span>`;
}

function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const bgClass = type === 'success' ? 'bg-success' : (type === 'danger' || type === 'error' ? 'bg-danger' : (type === 'warning' ? 'bg-warning text-dark' : 'bg-primary'));
  const toastId = 'toast-' + Date.now();

  const toastHtml = `
    <div id="${toastId}" class="toast align-items-center text-white ${bgClass} border-0 mb-2 shadow" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body">${escapeHtml(message)}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  `;
  container.insertAdjacentHTML('beforeend', toastHtml);

  const toastEl = document.getElementById(toastId);
  if (window.bootstrap) {
    const bsToast = new bootstrap.Toast(toastEl, { delay: 4000 });
    bsToast.show();
    toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
  } else {
    setTimeout(() => toastEl.remove(), 4000);
  }
}

function renderPagination(containerId, { page, totalPages }, onPageChange) {
  const container = document.getElementById(containerId);
  if (!container) return;

  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  let html = '<ul class="pagination pagination-sm justify-content-center mb-0">';
  html += `<li class="page-item ${page === 1 ? 'disabled' : ''}">
    <a class="page-link" href="#" data-page="${page - 1}">&laquo; Prev</a>
  </li>`;

  for (let p = 1; p <= totalPages; p++) {
    if (p === 1 || p === totalPages || (p >= page - 2 && p <= page + 2)) {
      html += `<li class="page-item ${p === page ? 'active' : ''}">
        <a class="page-link" href="#" data-page="${p}">${p}</a>
      </li>`;
    } else if (p === page - 3 || p === page + 3) {
      html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
  }

  html += `<li class="page-item ${page === totalPages ? 'disabled' : ''}">
    <a class="page-link" href="#" data-page="${page + 1}">Next &raquo;</a>
  </li></ul>`;

  container.innerHTML = html;

  container.querySelectorAll('a.page-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetPage = parseInt(link.getAttribute('data-page'), 10);
      if (!isNaN(targetPage) && targetPage >= 1 && targetPage <= totalPages && targetPage !== page) {
        onPageChange(targetPage);
      }
    });
  });
}
