// public/js/notifications.page.js: Notifications Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout();
  if (!user) return;

  let currentPage = 1;
  const limit = 10;

  async function loadNotifications(page = 1) {
    currentPage = page;
    const list = document.getElementById('notifList');
    list.innerHTML = '<div class="text-center py-5 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading notifications...</div>';

    try {
      const res = await api.get('/api/notifications', { page: currentPage, limit });
      const data = res.data || {};
      const items = data.records || [];
      const pagination = data.pagination || { total: items.length, page: 1, totalPages: 1 };

      let unreadCount = 0;
      items.forEach(n => {
        if (!n.is_read) unreadCount++;
      });
      document.getElementById('unreadCountBadge').textContent = `${unreadCount} unread`;

      if (items.length === 0) {
        list.innerHTML = `
          <div class="text-center py-5 text-muted">
            <i class="bi bi-bell-slash fs-1 d-block mb-2 text-secondary"></i>
            You have no notifications at this time.
          </div>
        `;
        document.getElementById('paginationInfo').textContent = 'Showing 0 of 0 items';
        document.getElementById('paginationControls').innerHTML = '';
        return;
      }

      list.innerHTML = items.map(n => {
        const isRead = n.is_read === true;
        const bgClass = isRead ? 'bg-white' : 'bg-primary-subtle bg-opacity-25';
        const icon = n.type === 'BOOKING_APPROVED' ? 'bi-check-circle-fill text-success' :
                     n.type === 'BOOKING_REJECTED' ? 'bi-x-circle-fill text-danger' :
                     n.type === 'DAMAGE_REPORTED' ? 'bi-exclamation-triangle-fill text-warning' :
                     'bi-info-circle-fill text-primary';

        const actionBtn = isRead
          ? '<span class="badge bg-secondary-subtle text-secondary"><i class="bi bi-check me-1"></i>Read</span>'
          : `<button class="btn btn-sm btn-outline-primary mark-read-btn" data-id="${n._id}">Mark as read</button>`;

        return `
          <div class="list-group-item list-group-item-action p-3 ${bgClass} border-bottom">
            <div class="d-flex w-100 justify-content-between align-items-center mb-1">
              <h6 class="mb-0 fw-${isRead ? 'normal' : 'bold'}">
                <i class="bi ${icon} me-2"></i>${escapeHtml(n.title || 'Notification')}
              </h6>
              <small class="text-muted">${escapeHtml(n.created_at || '')}</small>
            </div>
            <p class="mb-2 text-secondary small">${escapeHtml(n.message || '')}</p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="badge bg-light text-dark border font-monospace" style="font-size: 0.75rem;">${escapeHtml(n.type || 'SYSTEM')}</span>
              <div>${actionBtn}</div>
            </div>
          </div>
        `;
      }).join('');

      renderPagination(
        'paginationControls',
        'paginationInfo',
        pagination,
        (p) => loadNotifications(p)
      );

      document.querySelectorAll('.mark-read-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          try {
            await api.patch(`/api/notifications/${btn.dataset.id}/read`);
            showToast('Marked as read', 'success');
            loadNotifications(currentPage);
          } catch (err) {
            showToast(err.message, 'danger');
          }
        });
      });
    } catch (err) {
      list.innerHTML = `<div class="text-danger text-center py-4">Failed to load notifications: ${escapeHtml(err.message)}</div>`;
    }
  }

  document.getElementById('markAllReadBtn')?.addEventListener('click', async () => {
    try {
      await api.patch('/api/notifications/read-all');
      showToast('All notifications marked as read', 'success');
      loadNotifications(1);
    } catch (err) {
      showToast(err.message, 'danger');
    }
  });

  document.getElementById('refreshBtn')?.addEventListener('click', () => loadNotifications(currentPage));

  await loadNotifications(1);
});
