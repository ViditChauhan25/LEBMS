// public/js/approvals.page.js: Staff/Admin Approvals Management Logic
let currentPage = 1;
const limit = 10;

document.addEventListener('DOMContentLoaded', () => {
  loadApprovals(1);
  document.getElementById('refreshApprovalsBtn')?.addEventListener('click', () => loadApprovals(currentPage));
  document.getElementById('rejectForm')?.addEventListener('submit', handleRejectSubmit);
});

async function loadApprovals(page = 1) {
  currentPage = page;
  const tbody = document.getElementById('approvalsTableBody');
  tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm text-primary me-2"></div>Loading pending requests...</td></tr>`;

  try {
    const res = await api.get('/api/bookings', { status: 'REQUESTED', page, limit });
    const { items, total, totalPages } = res.data;

    if (!items || items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-muted"><i class="bi bi-check-circle fs-3 text-success d-block mb-1"></i>No pending booking requests in queue.</td></tr>`;
      document.getElementById('paginationInfo').textContent = '0 items';
      document.getElementById('paginationControls').innerHTML = '';
      return;
    }

    let rowsHtml = '';
    for (const b of items) {
      rowsHtml += `
        <tr>
          <td><span class="badge bg-light text-dark border font-monospace">#${b.booking_id}</span></td>
          <td>
            <div class="fw-semibold text-dark">${escapeHtml(b.user_name)}</div>
            <div class="small text-muted">${escapeHtml(b.user_email)} &bull; <span class="badge bg-secondary-subtle text-dark">${b.user_role}</span></div>
          </td>
          <td>
            <div class="fw-semibold text-dark">${escapeHtml(b.equipment_name)}</div>
            <div class="small font-monospace text-muted">${escapeHtml(b.equipment_code)}</div>
          </td>
          <td>${escapeHtml(b.lab_name)}</td>
          <td class="text-center fw-bold">${b.quantity}</td>
          <td class="small font-monospace">
            ${formatDateTime(b.start_datetime)}<br>
            <span class="text-muted">to</span> ${formatDateTime(b.end_datetime)}
          </td>
          <td><div class="text-truncate small" style="max-width: 220px;" title="${escapeHtml(b.purpose)}">${escapeHtml(b.purpose)}</div></td>
          <td class="text-end text-nowrap">
            <button class="btn btn-sm btn-success me-1 approve-btn" data-id="${b.booking_id}" title="Approve Request">
              <i class="bi bi-check-lg me-1"></i>Approve
            </button>
            <button class="btn btn-sm btn-danger reject-btn" data-id="${b.booking_id}" title="Reject Request">
              <i class="bi bi-x-lg me-1"></i>Reject
            </button>
          </td>
        </tr>
      `;
    }

    tbody.innerHTML = rowsHtml;

    tbody.querySelectorAll('.approve-btn').forEach(btn => {
      btn.addEventListener('click', () => handleApprove(btn.getAttribute('data-id')));
    });

    tbody.querySelectorAll('.reject-btn').forEach(btn => {
      btn.addEventListener('click', () => openRejectModal(btn.getAttribute('data-id')));
    });

    const startItem = (page - 1) * limit + 1;
    const endItem = Math.min(page * limit, total);
    document.getElementById('paginationInfo').textContent = `Showing ${startItem}-${endItem} of ${total} pending requests`;
    renderPagination('paginationControls', { page, totalPages }, (newPage) => loadApprovals(newPage));
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-danger">Error: ${escapeHtml(err.message)}</td></tr>`;
  }
}

async function handleApprove(bookingId) {
  if (!confirm(`Confirm approval for booking request #${bookingId}?`)) return;

  try {
    await api.patch(`/api/bookings/${bookingId}/approve`);
    showToast(`Booking #${bookingId} approved successfully`, 'success');
    loadApprovals(currentPage);
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

function openRejectModal(bookingId) {
  document.getElementById('rejectBookingId').value = bookingId;
  document.getElementById('rejectRemarks').value = '';
  const modalEl = document.getElementById('rejectModal');
  const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
  modal.show();
}

async function handleRejectSubmit(e) {
  e.preventDefault();
  const bookingId = document.getElementById('rejectBookingId').value;
  const remarks = document.getElementById('rejectRemarks').value.trim();

  try {
    await api.patch(`/api/bookings/${bookingId}/reject`, { remarks });
    showToast(`Booking #${bookingId} rejected`, 'info');
    const modalEl = document.getElementById('rejectModal');
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
    loadApprovals(currentPage);
  } catch (err) {
    showToast(err.message, 'danger');
  }
}
