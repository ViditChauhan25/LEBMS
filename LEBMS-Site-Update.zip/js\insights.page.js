// public/js/insights.page.js: Data Mining Insights Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout({ requiredRoles: ['ADMIN', 'STAFF', 'FACULTY'] });
  if (!user) return;

  const endpoints = [
    { key: 'mostBooked', url: '/api/mining/most-booked', col: 6 },
    { key: 'leastUsed', url: '/api/mining/least-used', col: 6 },
    { key: 'mostDamaged', url: '/api/mining/most-damaged', col: 6 },
    { key: 'peakMonth', url: '/api/mining/peak-month', col: 6 },
    { key: 'activeLab', url: '/api/mining/active-lab', col: 6 },
    { key: 'damageRate', url: '/api/mining/damage-rate', col: 6 },
    { key: 'bookedTogether', url: '/api/mining/booked-together', col: 12 }
  ];

  async function loadAllInsights() {
    const container = document.getElementById('insightsContainer');
    container.innerHTML = `
      <div class="col-12 text-center py-5">
        <div class="spinner-border text-primary" role="status"></div>
        <div class="mt-2 text-muted">Mining transactional patterns from MySQL database...</div>
      </div>
    `;

    try {
      const results = await Promise.all(endpoints.map(ep => api.get(ep.url).catch(err => ({ error: err.message }))));
      container.innerHTML = '';

      endpoints.forEach((ep, idx) => {
        const resp = results[idx];
        if (resp.error || !resp.data) {
          container.insertAdjacentHTML('beforeend', `
            <div class="col-md-${ep.col}">
              <div class="card card-custom p-3 text-danger">
                Failed to load insight: ${escapeHtml(resp.error || 'Server error')}
              </div>
            </div>
          `);
          return;
        }

        const insight = resp.data;
        const cardHtml = renderInsightCard(insight, idx, ep.col);
        container.insertAdjacentHTML('beforeend', cardHtml);
      });
    } catch (err) {
      container.innerHTML = `<div class="col-12 text-danger text-center py-4">Error loading data mining insights: ${escapeHtml(err.message)}</div>`;
    }
  }

  function renderInsightCard(data, idx, colSize) {
    const collapseId = `sqlCollapse_${idx}`;
    const rows = data.result || [];

    let tableHtml = '';
    if (rows.length === 0) {
      tableHtml = '<p class="text-muted small py-3 mb-0">No records found for this pattern.</p>';
    } else {
      const keys = Object.keys(rows[0]);
      tableHtml = `
        <div class="table-responsive" style="max-height: 280px;">
          <table class="table table-sm table-hover table-custom align-middle mb-0">
            <thead>
              <tr>
                ${keys.map(k => `<th>${escapeHtml(formatHeader(k))}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${rows.map(r => `
                <tr>
                  ${keys.map(k => {
                    let v = r[k];
                    if (v === null || v === undefined) v = '-';
                    if (typeof v === 'number' && k.includes('rate') || k.includes('percentage')) {
                      return `<td class="font-monospace text-primary fw-semibold">${escapeHtml(String(v))}%</td>`;
                    }
                    if (typeof v === 'number' || !isNaN(v)) {
                      return `<td class="font-monospace">${escapeHtml(String(v))}</td>`;
                    }
                    return `<td><small>${escapeHtml(String(v))}</small></td>`;
                  }).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }

    return `
      <div class="col-md-${colSize}">
        <div class="card card-custom h-100">
          <div class="card-header bg-white py-3 d-flex justify-content-between align-items-start">
            <div>
              <span class="badge bg-primary-subtle text-primary border mb-1">${escapeHtml(data.concept || 'Data Mining')}</span>
              <h6 class="fw-bold mb-0">${escapeHtml(data.title)}</h6>
            </div>
            <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#${collapseId}">
              <i class="bi bi-code-slash me-1"></i>View SQL
            </button>
          </div>
          <div class="card-body p-3">
            ${tableHtml}
            <div class="collapse mt-3" id="${collapseId}">
              <div class="bg-dark text-light p-3 rounded font-monospace small" style="white-space: pre-wrap; font-size: 0.8rem;">
                <div class="text-secondary mb-1 border-bottom border-secondary pb-1">
                  <i class="bi bi-database me-1"></i>UNDERLYING EXECUTED SQL QUERY
                </div>
${escapeHtml(data.query)}
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function formatHeader(key) {
    return key
      .replace(/_/g, ' ')
      .replace(/\b\w/g, c => c.toUpperCase());
  }

  document.getElementById('refreshInsightsBtn')?.addEventListener('click', loadAllInsights);

  await loadAllInsights();
});
