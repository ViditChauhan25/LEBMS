// public/js/api.js: Centralized API Fetch client with Netlify Static Fallback
const api = {
  // Simulated demo database for static hosting environments (Netlify / GitHub Pages)
  _demoData: {
    users: [
      { user_id: 1, full_name: 'System Admin', email: 'admin@gtu.ac.in', role: 'ADMIN', department_id: 1 },
      { user_id: 2, full_name: 'Lab Assistant', email: 'staff1@lab.edu', role: 'STAFF', department_id: 1 },
      { user_id: 3, full_name: 'Dr. Rajesh Patel', email: 'faculty@gtu.ac.in', role: 'FACULTY', department_id: 1 },
      { user_id: 4, full_name: 'Nikunj Hadiyal', email: 'student@gtu.ac.in', role: 'STUDENT', department_id: 1, enrollment_no: '2205016031001' }
    ],
    kpis: {
      totalEquipment: 52,
      availableUnits: 36,
      bookedUnits: 11,
      underMaintenance: 5
    },
    charts: {
      monthlyBookings: [
        { month: '2026-05', count: 18 },
        { month: '2026-06', count: 24 },
        { month: '2026-07', count: 31 },
        { month: '2026-08', count: 27 },
        { month: '2026-09', count: 45 },
        { month: '2026-10', count: 38 }
      ],
      monthlyTrend: [
        { month: '2026-05', count: 18 },
        { month: '2026-06', count: 24 },
        { month: '2026-07', count: 31 },
        { month: '2026-08', count: 27 },
        { month: '2026-09', count: 45 },
        { month: '2026-10', count: 38 }
      ],
      maintenanceSummary: [
        { status: 'SCHEDULED', count: 2 },
        { status: 'IN_PROGRESS', count: 3 },
        { status: 'COMPLETED', count: 14 }
      ],
      maintenanceStatus: [
        { status: 'SCHEDULED', count: 2 },
        { status: 'IN_PROGRESS', count: 3 },
        { status: 'COMPLETED', count: 14 }
      ],
      departmentUsage: [
        { department: 'Computer Engineering', code: 'CE', count: 48 },
        { department: 'Information Technology', code: 'IT', count: 36 },
        { department: 'Electronics & Communication', code: 'EC', count: 29 },
        { department: 'Mechanical Engineering', code: 'ME', count: 18 },
        { department: 'Electrical Engineering', code: 'EE', count: 12 }
      ],
      mostUsedEquipment: [
        { name: 'Digital Storage Oscilloscope', code: 'EQ-DSO', count: 28 },
        { name: 'Spectrum Analyzer 3GHz', code: 'EQ-SA', count: 22 },
        { name: 'Arbitrary Function Generator', code: 'EQ-AFG', count: 19 },
        { name: 'Precision Digital Multimeter', code: 'EQ-DMM', count: 15 },
        { name: 'FPGA Development Board', code: 'EQ-FPGA', count: 11 }
      ]
    },
    departments: [
      { department_id: 1, department_name: 'Computer Engineering', code: 'CE' },
      { department_id: 2, department_name: 'Electronics & Communication', code: 'EC' },
      { department_id: 3, department_name: 'Information Technology', code: 'IT' }
    ],
    labs: [
      { lab_id: 1, lab_name: 'Advanced Embedded Systems Lab', room_no: 'EC-204', department_id: 2 },
      { lab_id: 2, lab_name: 'VLSI & Microelectronics Lab', room_no: 'EC-301', department_id: 2 },
      { lab_id: 3, lab_name: 'Cloud & IoT Research Center', room_no: 'CE-405', department_id: 1 }
    ],
    equipment: [
      { equipment_id: 1, name: 'Digital Storage Oscilloscope 100MHz', category: 'TESTING', lab_name: 'Advanced Embedded Systems Lab', status: 'AVAILABLE', serial_number: 'EQ-DSO-101', purchase_cost: 45000 },
      { equipment_id: 2, name: 'RF Spectrum Analyzer 3GHz', category: 'RF_EQUIPMENT', lab_name: 'VLSI & Microelectronics Lab', status: 'BOOKED', serial_number: 'EQ-SA-202', purchase_cost: 120000 },
      { equipment_id: 3, name: 'Arbitrary Function Generator', category: 'TESTING', lab_name: 'Advanced Embedded Systems Lab', status: 'AVAILABLE', serial_number: 'EQ-AFG-303', purchase_cost: 32000 },
      { equipment_id: 4, name: 'Precision Digital Multimeter 6.5 Digit', category: 'MEASUREMENT', lab_name: 'Advanced Embedded Systems Lab', status: 'AVAILABLE', serial_number: 'EQ-DMM-404', purchase_cost: 28000 },
      { equipment_id: 5, name: 'Xilinx Artix-7 FPGA Dev Board', category: 'COMPUTING', lab_name: 'VLSI & Microelectronics Lab', status: 'AVAILABLE', serial_number: 'EQ-FPGA-505', purchase_cost: 38000 },
      { equipment_id: 6, name: 'Dual Channel Programmable DC Power Supply', category: 'POWER', lab_name: 'Advanced Embedded Systems Lab', status: 'UNDER_MAINTENANCE', serial_number: 'EQ-PS-606', purchase_cost: 24000 }
    ],
    bookings: [
      { booking_id: 101, equipment_name: 'Digital Storage Oscilloscope 100MHz', lab_name: 'Advanced Embedded Systems Lab', user_name: 'Nikunj Hadiyal', role: 'STUDENT', start_datetime: '2026-10-08T09:00:00Z', end_datetime: '2026-10-08T12:00:00Z', status: 'APPROVED' },
      { booking_id: 102, equipment_name: 'RF Spectrum Analyzer 3GHz', lab_name: 'VLSI & Microelectronics Lab', user_name: 'Dr. Rajesh Patel', role: 'FACULTY', start_datetime: '2026-10-07T10:00:00Z', end_datetime: '2026-10-07T16:00:00Z', status: 'ISSUED' },
      { booking_id: 103, equipment_name: 'Precision Digital Multimeter 6.5 Digit', lab_name: 'Advanced Embedded Systems Lab', user_name: 'Nikunj Hadiyal', role: 'STUDENT', start_datetime: '2026-10-05T14:00:00Z', end_datetime: '2026-10-05T17:00:00Z', status: 'CLOSED' },
      { booking_id: 104, equipment_name: 'Xilinx Artix-7 FPGA Dev Board', lab_name: 'VLSI & Microelectronics Lab', user_name: 'Meet Sharma', role: 'STUDENT', start_datetime: '2026-10-09T11:00:00Z', end_datetime: '2026-10-09T14:00:00Z', status: 'REQUESTED' }
    ],
    maintenance: [
      { task_id: 1, equipment_name: 'Dual Channel Programmable DC Power Supply', status: 'IN_PROGRESS', description: 'Annual calibration and thermal testing', priority: 'HIGH', scheduled_date: '2026-10-06' },
      { task_id: 2, equipment_name: 'Optical Microscope Olympus CX23', status: 'SCHEDULED', description: 'Lens cleaning and illumination check', priority: 'MEDIUM', scheduled_date: '2026-10-12' },
      { task_id: 3, equipment_name: 'Thermal Imaging Camera FLIR E5', status: 'COMPLETED', description: 'Battery pack replaced & firmware updated', priority: 'LOW', scheduled_date: '2026-10-02' }
    ]
  },

  _getDemoUser() {
    try {
      const stored = localStorage.getItem('lebms_demo_user');
      if (stored) return JSON.parse(stored);
    } catch (e) {}
    // Default fallback user based on current page / url query
    const isUserPortal = window.location.pathname.includes('my-bookings') || 
                         window.location.pathname.includes('book') || 
                         window.location.search.includes('role=user');
    return isUserPortal ? this._demoData.users[3] : this._demoData.users[0];
  },

  _setDemoUser(user) {
    try {
      localStorage.setItem('lebms_demo_user', JSON.stringify(user));
    } catch (e) {}
  },

  _handleMockFallback(url, options = {}) {
    const method = (options.method || 'GET').toUpperCase();
    const cleanUrl = url.split('?')[0].replace(/\/$/, '');
    console.info(`[LEBMS Demo Mode] Handling ${method} ${cleanUrl}`);

    // Auth endpoints
    if (cleanUrl.endsWith('/api/auth/login')) {
      let body = {};
      try { body = typeof options.body === 'string' ? JSON.parse(options.body) : (options.body || {}); } catch (e) {}
      const email = (body.email || '').toLowerCase();
      let matchedUser = this._demoData.users.find(u => u.email.toLowerCase() === email);
      if (!matchedUser) {
        if (email.includes('admin')) matchedUser = this._demoData.users[0];
        else if (email.includes('faculty')) matchedUser = this._demoData.users[2];
        else if (email.includes('staff')) matchedUser = this._demoData.users[1];
        else matchedUser = this._demoData.users[3]; // default student
      }
      this._setDemoUser(matchedUser);
      return { success: true, message: 'Login successful (Netlify Demo Mode)', data: matchedUser };
    }

    if (cleanUrl.endsWith('/api/auth/me')) {
      const user = this._getDemoUser();
      return { success: true, data: user };
    }

    if (cleanUrl.endsWith('/api/auth/logout')) {
      try { localStorage.removeItem('lebms_demo_user'); } catch (e) {}
      window.location.href = '/login.html';
      return { success: true, message: 'Logged out' };
    }

    // Dashboard endpoints
    if (cleanUrl.endsWith('/api/dashboard/kpis') || cleanUrl.endsWith('/api/stats/kpis')) {
      return { success: true, data: this._demoData.kpis };
    }

    if (cleanUrl.endsWith('/api/dashboard/charts') || cleanUrl.endsWith('/api/stats/charts')) {
      return { success: true, data: this._demoData.charts };
    }

    if (cleanUrl.endsWith('/api/stats/dashboard')) {
      return { success: true, data: { ...this._demoData.kpis, ...this._demoData.charts } };
    }

    // Catalog & Metadata
    if (cleanUrl.endsWith('/api/departments')) {
      return { success: true, data: this._demoData.departments };
    }

    if (cleanUrl.endsWith('/api/labs')) {
      return { success: true, data: this._demoData.labs };
    }

    if (cleanUrl.endsWith('/api/equipment')) {
      return { success: true, data: this._demoData.equipment };
    }

    // Bookings
    if (cleanUrl.endsWith('/api/bookings/my')) {
      const studentBookings = this._demoData.bookings.filter(b => b.role === 'STUDENT' || b.user_name === 'Nikunj Hadiyal');
      return { success: true, data: { items: studentBookings, total: studentBookings.length } };
    }

    if (cleanUrl.endsWith('/api/bookings')) {
      if (method === 'POST') {
        return { success: true, message: 'Equipment booking request submitted successfully! (Demo Mode)', data: { booking_id: Math.floor(Math.random() * 900) + 100 } };
      }
      return { success: true, data: { items: this._demoData.bookings, total: this._demoData.bookings.length } };
    }

    // Maintenance
    if (cleanUrl.endsWith('/api/maintenance')) {
      return { success: true, data: this._demoData.maintenance };
    }

    // Notifications
    if (cleanUrl.endsWith('/api/notifications/unread-count')) {
      return { success: true, data: { count: 2 } };
    }

    if (cleanUrl.endsWith('/api/notifications')) {
      return {
        success: true,
        data: [
          { notification_id: 1, title: 'Booking Approved', message: 'Your booking for Digital Storage Oscilloscope is approved.', created_at: '2026-10-07T08:00:00Z', is_read: false },
          { notification_id: 2, title: 'Calibration Notice', message: 'Lab 204 equipment undergoes maintenance on Friday.', created_at: '2026-10-06T14:30:00Z', is_read: false }
        ]
      };
    }

    // XML Schema / Demo endpoints
    if (cleanUrl.includes('/api/xml')) {
      return { success: true, message: 'XML Schema validated against GTU XSD standard.', valid: true };
    }

    // Generic fallback for any other POST/PUT/DELETE
    if (method !== 'GET') {
      return { success: true, message: 'Action completed successfully (Netlify Demo Mode)' };
    }

    // Generic list fallback
    return { success: true, data: [] };
  },

  async request(url, options = {}) {
    options.headers = options.headers || {};
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }
    options.credentials = 'same-origin';

    try {
      const res = await fetch(url, options);

      // Handle 401 Unauthenticated redirect
      if (res.status === 401) {
        if (!window.location.pathname.endsWith('login.html')) {
          window.location.href = '/login.html';
        }
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.message || 'Authentication required');
      }

      // If static host returns 404 for API route, seamlessly fallback to demo data
      if (res.status === 404 && url.includes('/api/')) {
        return this._handleMockFallback(url, options);
      }

      // Check if response is JSON
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        if (!res.ok) {
          const txt = await res.text();
          throw new Error(txt || `HTTP error ${res.status}`);
        }
        return res;
      }

      const json = await res.json();
      if (!res.ok || json.success === false) {
        const errorMsg = json.message || `Request failed (${res.status})`;
        if (typeof showToast === 'function') {
          showToast(errorMsg, 'danger');
        }
        const err = new Error(errorMsg);
        err.status = res.status;
        err.data = json;
        throw err;
      }

      return json;
    } catch (err) {
      // If network fails (e.g., frontend deployed standalone on Netlify without local backend)
      if (url.includes('/api/') && (!err.status || err.status === 404 || err.name === 'TypeError')) {
        return this._handleMockFallback(url, options);
      }
      console.error(`[API Error] ${options.method || 'GET'} ${url}:`, err);
      throw err;
    }
  },

  get(url, params = {}) {
    const query = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') {
        query.append(k, v);
      }
    }
    const qStr = query.toString();
    const finalUrl = qStr ? `${url}?${qStr}` : url;
    return this.request(finalUrl, { method: 'GET' });
  },

  post(url, body) {
    return this.request(url, { method: 'POST', body });
  },

  put(url, body) {
    return this.request(url, { method: 'PUT', body });
  },

  patch(url, body) {
    return this.request(url, { method: 'PATCH', body });
  },

  delete(url) {
    return this.request(url, { method: 'DELETE' });
  }
};
