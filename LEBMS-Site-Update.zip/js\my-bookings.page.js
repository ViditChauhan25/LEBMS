// public/js/my-bookings.page.js: User Bookings Listing & Cancellation
let currentPage = 1;
const limit = 10;

document.addEventListener('DOMContentLoaded', () => {
  loadMyBookings(1);
});

async function loadMyBookings(page = 1) {
  currentPage = page;
  const tbody = document.getElementById('bookingsTableBody');
  tbody.innerHTML = `<tr><td colspan="9" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm text-primary me-2"></div>Loading reservations...</td></tr>`;

  try {
    const res = await api.get('/api/bookings/my', { page, limit });
    const { items, total, totalPages } = res.data;

    if (!items || items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" class="text-center py-4 text-muted"><i class="bi bi-inbox fs-3 d-block mb-1"></i>You have no booking reservations yet.</td></tr>`;
      document.getElementById('paginationInfo').textContent = '0 items';
      document.getElementById('paginationControls').innerHTML = '';
      return;
    }

    let rowsHtml = '';
    for (const b of items) {
      const canCancel = ['REQUESTED', 'APPROVED'].includes(b.status);
      const actionHtml = canCancel
        ? `<button class="btn btn-sm btn-outline-danger cancel-btn" data-id="${b.booking_id}"><i class="bi bi-x-circle me-1"></i>Cancel</button>`
        : `<span class="text-muted small">&mdash;</span>`;

      rowsHtml += `
        <tr>
          <td><span class="badge bg-light text-dark border font-monospace">#${b.booking_id}</span></td>
          <td>
            <div class="fw-semibold text-dark">${escapeHtml(b.equipment_name)}</div>
            <div class="small text-muted font-monospace">${escapeHtml(b.equipment_code)}</div>
          </td>
          <td>${escapeHtml(b.lab_name)}</td>
          <td class="text-center fw-bold">${b.quantity}</td>
          <td class="small font-monospace">${formatDateTime(b.start_datetime)}</td>
          <td class="small font-monospace">${formatDateTime(b.end_datetime)}</td>
          <td><div class="text-truncate small" style="max-width: 200px;" title="${escapeHtml(b.purpose)}">${escapeHtml(b.purpose)}</div></td>
          <td>${renderStatusBadge(b.status)}</td>
          <td class="text-end text-nowrap">${actionHtml}</td>
        </tr>
      `;
    }

    tbody.innerHTML = rowsHtml;

    tbody.querySelectorAll('.cancel-btn').forEach(btn => {
      btn.addEventListener('click', () => handleCancel(btn.getAttribute('data-id')));
    });

    const startItem = (page - 1) * limit + 1;
    const endItem = Math.min(page * limit, total);
    document.getElementById('paginationInfo').textContent = `Showing ${startItem}-${endItem} of ${total} reservations`;
    renderPagination('paginationControls', { page, totalPages }, (newPage) => loadMyBookings(newPage));
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="9" class="text-center py-4 text-danger">Error: ${escapeHtml(err.message)}</td></tr>`;
  }
}

async function handleCancel(bookingId) {
  if (!confirm(`Are you sure you want to cancel booking request #${bookingId}?`)) return;

  try {
    await api.patch(`/api/bookings/${bookingId}/cancel`);
    showToast(`Booking #${bookingId} cancelled`, 'success');
    loadMyBookings(currentPage);
  } catch (err) {
    showToast(err.message, 'danger');
  }
}
