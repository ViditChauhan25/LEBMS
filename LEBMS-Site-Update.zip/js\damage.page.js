// public/js/damage.page.js: Damage Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout({ requiredRoles: ['ADMIN', 'STAFF'] });
  if (!user) return;

  let currentPage = 1;
  const limit = 10;
  let damageModalInst = null;

  if (window.bootstrap) {
    const dEl = document.getElementById('newDamageModal');
    if (dEl) damageModalInst = new bootstrap.Modal(dEl);
  }

  async function loadEquipmentOptions() {
    try {
      const res = await api.get('/api/equipment?limit=200');
      const select = document.getElementById('damageEquipSelect');
      if (!select) return;
      select.innerHTML = '<option value="">Select Equipment...</option>';
      const items = res.data && res.data.equipment ? res.data.equipment : (res.data || []);
      items.forEach(eq => {
        const opt = document.createElement('option');
        opt.value = eq.equipment_id;
        opt.textContent = `${eq.equipment_code} - ${eq.equipment_name} (${eq.lab_code || ''} [${eq.status}])`;
        select.appendChild(opt);
      });
    } catch (err) {
      console.error('Failed to load equipment options:', err);
    }
  }

  async function loadDamageReports(page = 1) {
    currentPage = page;
    const tbody = document.getElementById('damageTableBody');
    tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading incidents...</td></tr>';

    try {
      const res = await api.get('/api/damage', { page: currentPage, limit });
      const data = res.data || {};
      const items = data.records || [];
      const pagination = data.pagination || { total: items.length, page: 1, totalPages: 1 };

      // Update counters from all visible data
      let reported = 0, review = 0, resolved = 0;
      items.forEach(d => {
        if (d.status === 'REPORTED') reported++;
        else if (d.status === 'UNDER_REVIEW') review++;
        else if (d.status === 'RESOLVED') resolved++;
      });
      document.getElementById('countReported').textContent = reported;
      document.getElementById('countReview').textContent = review;
      document.getElementById('countResolved').textContent = resolved;

      if (items.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted">No damage reports on record.</td></tr>';
        document.getElementById('paginationInfo').textContent = 'Showing 0 of 0 items';
        document.getElementById('paginationControls').innerHTML = '';
        return;
      }

      tbody.innerHTML = items.map(d => {
        let badgeClass = 'badge-danger';
        if (d.status === 'UNDER_REVIEW') badgeClass = 'badge-warning';
        if (d.status === 'RESOLVED') badgeClass = 'badge-success';

        let sevBadge = 'bg-secondary';
        if (d.severity === 'MAJOR') sevBadge = 'bg-warning text-dark';
        if (d.severity === 'CRITICAL') sevBadge = 'bg-danger';

        let actionHtml = '';
        if (d.status === 'REPORTED') {
          actionHtml = `
            <button class="btn btn-sm btn-outline-warning review-btn" data-id="${d.damage_id}">
              <i class="bi bi-search me-1"></i>Mark Review
            </button>
          `;
        } else if (d.status === 'UNDER_REVIEW') {
          actionHtml = `
            <button class="btn btn-sm btn-success resolve-btn" data-id="${d.damage_id}">
              <i class="bi bi-check2-circle me-1"></i>Resolve
            </button>
          `;
        } else {
          actionHtml = `<span class="badge bg-secondary"><i class="bi bi-check-all me-1"></i>Resolved</span>`;
        }

        return `
          <tr>
            <td class="fw-bold">#${d.damage_id}</td>
            <td>
              <div class="fw-semibold">${escapeHtml(d.equipment_name || 'Equipment #' + d.equipment_id)}</div>
              <small class="text-muted font-monospace">${escapeHtml(d.equipment_code || '')}</small>
            </td>
            <td>
              <div>${escapeHtml(d.reporter_name || 'User #' + d.reported_by)}</div>
            </td>
            <td><small class="text-secondary">${escapeHtml(d.damage_description)}</small></td>
            <td><span class="badge ${sevBadge}">${escapeHtml(d.severity)}</span></td>
            <td><small>${escapeHtml(d.reported_at || '-')}</small></td>
            <td><small>${escapeHtml(d.resolved_at || '-')}</small></td>
            <td><span class="badge ${badgeClass}">${escapeHtml(d.status)}</span></td>
            <td class="text-end text-nowrap">${actionHtml}</td>
          </tr>
        `;
      }).join('');

      renderPagination(
        'paginationControls',
        'paginationInfo',
        pagination,
        (p) => loadDamageReports(p)
      );

      // Attach button listeners
      document.querySelectorAll('.review-btn').forEach(btn => {
        btn.addEventListener('click', () => updateStatus(btn.dataset.id, 'UNDER_REVIEW'));
      });
      document.querySelectorAll('.resolve-btn').forEach(btn => {
        btn.addEventListener('click', () => updateStatus(btn.dataset.id, 'RESOLVED'));
      });
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="9" class="text-center py-4 text-danger"><i class="bi bi-exclamation-triangle me-1"></i>Failed to load damage reports: ${escapeHtml(err.message)}</td></tr>`;
    }
  }

  async function updateStatus(id, newStatus) {
    if (!confirm(`Transition damage report #${id} to ${newStatus}?`)) return;
    try {
      await api.patch(`/api/damage/${id}/status`, { status: newStatus });
      showToast(`Incident #${id} transitioned to ${newStatus}.`, 'success');
      loadDamageReports(currentPage);
    } catch (err) {
      showToast(err.message, 'danger');
    }
  }

  // Handle New Damage Form
  const form = document.getElementById('damageForm');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const payload = {
        equipment_id: parseInt(document.getElementById('damageEquipSelect').value, 10),
        severity: document.getElementById('damageSeverity').value,
        damage_description: document.getElementById('damageDesc').value.trim()
      };

      try {
        await api.post('/api/damage', payload);
        showToast('Damage report submitted! Equipment is now UNDER_MAINTENANCE.', 'success');
        form.reset();
        if (damageModalInst) damageModalInst.hide();
        loadDamageReports(1);
      } catch (err) {
        showToast(err.message, 'danger');
      }
    });
  }

  document.getElementById('refreshBtn')?.addEventListener('click', () => loadDamageReports(currentPage));

  await loadEquipmentOptions();
  await loadDamageReports(1);
});
