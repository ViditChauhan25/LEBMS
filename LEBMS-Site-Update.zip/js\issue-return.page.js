// public/js/issue-return.page.js: Issue, Return, and Verification Closure Desk
document.addEventListener('DOMContentLoaded', () => {
  loadDeskData();
  document.getElementById('refreshDeskBtn')?.addEventListener('click', loadDeskData);
  document.getElementById('issueForm')?.addEventListener('submit', handleIssueSubmit);
  document.getElementById('returnForm')?.addEventListener('submit', handleReturnSubmit);

  document.getElementById('returnCondition')?.addEventListener('change', (e) => {
    const isDamaged = e.target.value === 'DAMAGED';
    document.getElementById('damageSeverityGroup')?.classList.toggle('d-none', !isDamaged);
  });
});

async function loadDeskData() {
  await Promise.all([
    loadReadyToIssue(),
    loadAwaitingReturn(),
    loadVerifyClose()
  ]);
}

// 1. Ready to Issue (APPROVED bookings)
async function loadReadyToIssue() {
  const tbody = document.getElementById('readyToIssueBody');
  tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">Loading approved bookings...</td></tr>`;

  try {
    const res = await api.get('/api/bookings', { status: 'APPROVED', limit: 50 });
    const items = res.data.items || [];
    document.getElementById('badge-issue-count').textContent = items.length;

    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">No approved bookings ready for issue.</td></tr>`;
      return;
    }

    tbody.innerHTML = items.map(b => `
      <tr>
        <td><span class="badge bg-light text-dark border font-monospace">#${b.booking_id}</span></td>
        <td>
          <div class="fw-semibold">${escapeHtml(b.user_name)}</div>
          <div class="small text-muted">${escapeHtml(b.user_email)}</div>
        </td>
        <td>
          <div class="fw-semibold">${escapeHtml(b.equipment_name)}</div>
          <div class="small text-muted font-monospace">${escapeHtml(b.equipment_code)}</div>
        </td>
        <td>${escapeHtml(b.lab_name)}</td>
        <td class="text-center fw-bold">${b.quantity}</td>
        <td class="small font-monospace">${formatDateTime(b.start_datetime)} &bull; ${formatDateTime(b.end_datetime)}</td>
        <td class="text-end">
          <button class="btn btn-sm btn-primary issue-action-btn" data-id="${b.booking_id}">
            <i class="bi bi-box-arrow-up-right me-1"></i>Issue
          </button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.issue-action-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.getElementById('issueBookingId').value = btn.getAttribute('data-id');
        document.getElementById('issueRemarks').value = '';
        new bootstrap.Modal(document.getElementById('issueModal')).show();
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-danger">${escapeHtml(err.message)}</td></tr>`;
  }
}

// 2. Awaiting Return (ISSUED bookings)
async function loadAwaitingReturn() {
  const tbody = document.getElementById('awaitingReturnBody');
  tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">Loading issued items...</td></tr>`;

  try {
    const res = await api.get('/api/bookings', { status: 'ISSUED', limit: 50 });
    const items = res.data.items || [];
    document.getElementById('badge-return-count').textContent = items.length;

    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">No equipment currently checked out.</td></tr>`;
      return;
    }

    tbody.innerHTML = items.map(b => `
      <tr>
        <td><span class="badge bg-light text-dark border font-monospace">#${b.booking_id}</span></td>
        <td>
          <div class="fw-semibold">${escapeHtml(b.user_name)}</div>
          <div class="small text-muted">${escapeHtml(b.user_email)}</div>
        </td>
        <td>
          <div class="fw-semibold">${escapeHtml(b.equipment_name)}</div>
          <div class="small text-muted font-monospace">${escapeHtml(b.equipment_code)}</div>
        </td>
        <td class="text-center fw-bold">${b.quantity}</td>
        <td class="small font-monospace">${formatDateTime(b.start_datetime)}</td>
        <td class="small font-monospace text-danger">${formatDateTime(b.end_datetime)}</td>
        <td class="text-end">
          <button class="btn btn-sm btn-warning return-action-btn" data-id="${b.booking_id}">
            <i class="bi bi-box-arrow-in-down-left me-1"></i>Receive Return
          </button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.return-action-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.getElementById('returnBookingId').value = btn.getAttribute('data-id');
        document.getElementById('returnCondition').value = 'GOOD';
        document.getElementById('damageSeverityGroup').classList.add('d-none');
        document.getElementById('returnRemarks').value = '';
        new bootstrap.Modal(document.getElementById('returnModal')).show();
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-danger">${escapeHtml(err.message)}</td></tr>`;
  }
}

// 3. Verify & Close (RETURNED bookings)
async function loadVerifyClose() {
  const tbody = document.getElementById('verifyCloseBody');
  tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">Loading returned items...</td></tr>`;

  try {
    const res = await api.get('/api/bookings', { status: 'RETURNED', limit: 50 });
    const items = res.data.items || [];
    document.getElementById('badge-close-count').textContent = items.length;

    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">No returned items waiting for closure.</td></tr>`;
      return;
    }

    tbody.innerHTML = items.map(b => `
      <tr>
        <td><span class="badge bg-light text-dark border font-monospace">#${b.booking_id}</span></td>
        <td>
          <div class="fw-semibold">${escapeHtml(b.user_name)}</div>
          <div class="small text-muted">${escapeHtml(b.user_role)}</div>
        </td>
        <td>
          <div class="fw-semibold">${escapeHtml(b.equipment_name)}</div>
          <div class="small text-muted font-monospace">${escapeHtml(b.equipment_code)}</div>
        </td>
        <td class="text-center fw-bold">${b.quantity}</td>
        <td class="small font-monospace">${formatDateTime(b.updated_at || b.end_datetime)}</td>
        <td>${renderStatusBadge(b.status)}</td>
        <td class="text-end">
          <button class="btn btn-sm btn-dark close-action-btn" data-id="${b.booking_id}">
            <i class="bi bi-check2-all me-1"></i>Verify &amp; Close
          </button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.close-action-btn').forEach(btn => {
      btn.addEventListener('click', () => handleCloseBooking(btn.getAttribute('data-id')));
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-danger">${escapeHtml(err.message)}</td></tr>`;
  }
}

async function handleIssueSubmit(e) {
  e.preventDefault();
  const bookingId = document.getElementById('issueBookingId').value;
  const condition = document.getElementById('issueCondition').value;
  const remarks = document.getElementById('issueRemarks').value.trim();

  try {
    await api.post('/api/issues', { bookingId, condition, remarks });
    showToast('Equipment issued successfully', 'success');
    bootstrap.Modal.getInstance(document.getElementById('issueModal'))?.hide();
    loadDeskData();
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function handleReturnSubmit(e) {
  e.preventDefault();
  const bookingId = document.getElementById('returnBookingId').value;
  const condition = document.getElementById('returnCondition').value;
  const severity = document.getElementById('returnSeverity').value;
  const remarks = document.getElementById('returnRemarks').value.trim();

  try {
    const res = await api.post('/api/returns', { bookingId, condition, severity, remarks });
    if (res.data.damaged) {
      showToast('Return recorded as DAMAGED. Damage report & maintenance scheduled.', 'warning');
    } else {
      showToast('Return processed successfully', 'success');
    }
    bootstrap.Modal.getInstance(document.getElementById('returnModal'))?.hide();
    loadDeskData();
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function handleCloseBooking(bookingId) {
  if (!confirm(`Verify physical inventory and close booking #${bookingId}?`)) return;

  try {
    await api.patch(`/api/bookings/${bookingId}/close`);
    showToast(`Booking #${bookingId} verified and closed`, 'success');
    loadDeskData();
  } catch (err) {
    showToast(err.message, 'danger');
  }
}
