// public/js/layout.js: Dual Layout Engine (Enterprise Admin Sidebar vs. Campus User Top-Nav)
document.addEventListener('DOMContentLoaded', async () => {
  // Skip on login page
  if (window.location.pathname.endsWith('login.html')) return;

  try {
    const res = await api.get('/api/auth/me');
    const user = res.data;
    window.currentUser = user;

    if (['ADMIN', 'STAFF'].includes(user.role)) {
      renderAdminEnterpriseLayout(user);
    } else {
      renderUserPortalLayout(user);
    }

    fetchUnreadNotificationsCount();
  } catch (err) {
    console.warn('[Layout] Authentication check failed:', err.message);
  }
});

/* ============================================================
   1. USER SIDE LAYOUT: MODERN CAMPUS HORIZONTAL TOP-NAV
   ============================================================ */
function renderUserPortalLayout(user) {
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  const mainEl = document.querySelector('main');
  if (!mainEl) return;

  const userInitial = (user.full_name || 'U').charAt(0).toUpperCase();

  const navLinks = [
    { href: 'index.html', label: 'Portal Home', icon: 'bi-grid-fill' },
    { href: 'equipment.html', label: 'Equipment Catalog', icon: 'bi-cpu-fill' },
    { href: 'book.html', label: 'Book Equipment', icon: 'bi-calendar-plus-fill' },
    { href: 'my-bookings.html', label: 'My Bookings', icon: 'bi-journal-check' },
    { href: 'damage.html', label: 'Report Damage', icon: 'bi-exclamation-triangle-fill' }
  ];

  const portalLayout = document.createElement('div');
  portalLayout.className = 'user-portal-layout';

  // Top Nav Bar
  const navBar = document.createElement('nav');
  navBar.className = 'user-top-navbar navbar navbar-expand-lg';
  navBar.innerHTML = `
    <div class="container-fluid px-4">
      <a class="user-brand-logo" href="index.html">
        <div class="user-brand-icon">
          <i class="bi bi-mortarboard-fill"></i>
        </div>
        <div>
          <div class="d-flex align-items-center">
            <span>LEBMS</span>
            <span class="badge bg-success-subtle text-success border border-success-subtle ms-2" style="font-size: 0.65rem;">STUDENT PORTAL</span>
          </div>
          <div class="text-muted" style="font-size: 0.7rem; font-weight: 500;">GTU BE05016031 Laboratory System</div>
        </div>
      </a>

      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#userNavCollapse" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-center" id="userNavCollapse">
        <div class="user-nav-pills my-2 my-lg-0">
          ${navLinks.map(link => `
            <a href="${link.href}" class="user-nav-link ${currentPath === link.href ? 'active' : ''}">
              <i class="bi ${link.icon}"></i>
              <span>${link.label}</span>
            </a>
          `).join('')}
        </div>
      </div>

      <div class="d-flex align-items-center gap-2">
        <!-- Presentation Shortcut -->
        <a href="presentation.html" class="btn btn-sm btn-outline-secondary rounded-pill px-2 d-none d-sm-inline-flex align-items-center" title="Viva Presentation Slides">
          <i class="bi bi-easel2-fill text-warning me-1"></i><span class="small">Viva Deck</span>
        </a>

        <!-- Notification Bell -->
        <a href="notifications.html" class="btn btn-sm btn-light border position-relative rounded-circle p-2" title="Notifications" style="width: 38px; height: 38px;">
          <i class="bi bi-bell-fill text-secondary"></i>
          <span id="notif-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none" style="font-size: 0.65rem;">0</span>
        </a>

        <!-- User Profile Dropdown -->
        <div class="dropdown">
          <button class="btn btn-sm btn-light border dropdown-toggle d-flex align-items-center rounded-pill px-2 py-1" type="button" id="userPortalDropdown" data-bs-toggle="dropdown" aria-expanded="false">
            <div class="user-avatar-badge me-2" style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); width: 28px; height: 28px; font-size: 0.75rem;">${userInitial}</div>
            <span class="d-none d-md-inline fw-semibold text-dark small me-1">${escapeHtml(user.full_name)}</span>
            <span class="badge bg-secondary ms-1" style="font-size: 0.65rem;">${user.role}</span>
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-3 mt-2" aria-labelledby="userPortalDropdown">
            <li><h6 class="dropdown-header text-dark fw-bold">${escapeHtml(user.full_name)}</h6></li>
            <li><span class="dropdown-item-text text-muted small">${escapeHtml(user.email)}</span></li>
            ${user.enrollment_no ? `<li><span class="dropdown-item-text text-muted small">Enrollment: ${escapeHtml(user.enrollment_no)}</span></li>` : ''}
            <li><hr class="dropdown-divider"></li>
            <li>
              <button id="userPortalLogoutBtn" class="dropdown-item text-danger d-flex align-items-center">
                <i class="bi bi-box-arrow-right me-2"></i>Sign Out
              </button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
  `;
  portalLayout.appendChild(navBar);

  // Content Body
  const contentBody = document.createElement('div');
  contentBody.className = 'user-portal-body';
  mainEl.parentNode.insertBefore(portalLayout, mainEl);
  contentBody.appendChild(mainEl);
  portalLayout.appendChild(contentBody);

  // Footer
  const footer = document.createElement('footer');
  footer.className = 'user-portal-footer';
  footer.innerHTML = `
    <div class="container-fluid px-4 d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
      <div>
        <span>LEBMS Student Portal · GTU BE05016031 Laboratory System</span>
      </div>
      <div class="d-flex align-items-center gap-3">
        <a href="book.html" class="text-decoration-none text-success fw-semibold"><i class="bi bi-calendar-plus me-1"></i>New Booking</a>
        <a href="presentation.html" class="text-decoration-none text-primary fw-semibold"><i class="bi bi-easel2-fill me-1 text-warning"></i>Viva Deck</a>
      </div>
    </div>
  `;
  portalLayout.appendChild(footer);

  document.getElementById('userPortalLogoutBtn')?.addEventListener('click', async () => {
    try {
      await api.post('/api/auth/logout');
      window.location.href = '/login.html';
    } catch (e) {
      window.location.href = '/login.html';
    }
  });
}

/* ============================================================
   2. ADMIN SIDE LAYOUT: ENTERPRISE DARK VERTICAL SIDEBAR
   ============================================================ */
function renderAdminEnterpriseLayout(user) {
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  const role = user.role;
  const mainEl = document.querySelector('main');
  if (!mainEl) return;

  const pageTitles = {
    'index.html': 'Executive Operations Dashboard',
    'equipment.html': 'Equipment Inventory Management',
    'approvals.html': 'Booking Approvals Hub',
    'issue-return.html': 'Issue & Return Records',
    'maintenance.html': 'Maintenance Work Hub',
    'damage.html': 'Damage Incident Reports',
    'reports.html': 'Institutional Reports & Ledgers',
    'insights.html': 'Data Mining & Usage Analytics',
    'xml.html': 'XML & XPath Engine Hub',
    'showcase.html': 'ACID Concurrency Demos',
    'labs.html': 'College Laboratories',
    'users.html': 'User Roster & Permissions',
    'notifications.html': 'System Notifications',
    'presentation.html': 'Viva Slide Deck'
  };

  const currentPageTitle = pageTitles[currentPath] || 'Operations';

  const navSections = [
    {
      title: 'Operations',
      items: [
        { href: 'index.html', label: 'Dashboard', icon: 'bi-speedometer2' },
        { href: 'equipment.html', label: 'Equipment Catalog', icon: 'bi-cpu' },
        { href: 'approvals.html', label: 'Booking Approvals', icon: 'bi-check2-circle' }
      ]
    },
    {
      title: 'Circulation Desk',
      items: [
        { href: 'issue-return.html', label: 'Issue & Return', icon: 'bi-arrow-left-right' },
        { href: 'maintenance.html', label: 'Maintenance Hub', icon: 'bi-wrench-adjustable' },
        { href: 'damage.html', label: 'Damage Reports', icon: 'bi-exclamation-triangle' }
      ]
    },
    {
      title: 'Analytics & XML',
      items: [
        { href: 'reports.html', label: 'Institutional Reports', icon: 'bi-file-earmark-bar-graph' },
        { href: 'insights.html', label: 'Data Mining Insights', icon: 'bi-graph-up-arrow' },
        { href: 'xml.html', label: 'XML & XPath Hub', icon: 'bi-filetype-xml' },
        { href: 'showcase.html', label: 'ACID Concurrency Demos', icon: 'bi-mortarboard' }
      ]
    },
    ...( role === 'ADMIN' ? [{
      title: 'System Administration',
      items: [
        { href: 'labs.html', label: 'Laboratories', icon: 'bi-building' },
        { href: 'users.html', label: 'User Accounts', icon: 'bi-people' }
      ]
    }] : [] ),
    {
      title: 'Viva & Evaluation',
      items: [
        { href: 'presentation.html', label: 'Presentation Deck', icon: 'bi-easel2' }
      ]
    }
  ];

  const userInitial = (user.full_name || 'A').charAt(0).toUpperCase();

  const appLayout = document.createElement('div');
  appLayout.className = 'app-layout';

  const backdrop = document.createElement('div');
  backdrop.id = 'sidebarBackdrop';
  backdrop.className = 'app-sidebar-backdrop';
  appLayout.appendChild(backdrop);

  // Sidebar
  const sidebar = document.createElement('aside');
  sidebar.id = 'appSidebar';
  sidebar.className = 'app-sidebar';
  sidebar.innerHTML = `
    <div class="sidebar-header">
      <a href="index.html" class="sidebar-brand">
        <div class="sidebar-brand-icon">
          <i class="bi bi-shield-lock-fill"></i>
        </div>
        <div>
          <div class="sidebar-brand-text">LEBMS</div>
          <div class="text-white-50" style="font-size: 0.7rem; font-weight: 500;">Admin Operations Portal</div>
        </div>
      </a>
      <button class="btn btn-sm btn-link text-white-50 p-1 d-lg-none" id="sidebarCloseBtn" aria-label="Close sidebar">
        <i class="bi bi-x-lg fs-5"></i>
      </button>
    </div>

    <div class="sidebar-nav">
      ${navSections.map(section => {
        if (!section.items || section.items.length === 0) return '';
        return `
          <div class="sidebar-section-title">${section.title}</div>
          ${section.items.map(item => `
            <a href="${item.href}" class="sidebar-link ${currentPath === item.href ? 'active' : ''}">
              <i class="bi ${item.icon}"></i>
              <span>${item.label}</span>
            </a>
          `).join('')}
        `;
      }).join('')}
    </div>

    <div class="sidebar-footer">
      <div class="d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center overflow-hidden me-2">
          <div class="user-avatar-badge me-2 flex-shrink-0">${userInitial}</div>
          <div class="text-truncate">
            <div class="fw-semibold text-white small text-truncate" style="line-height: 1.2;">${escapeHtml(user.full_name)}</div>
            <span class="badge bg-primary" style="font-size: 0.65rem;">${user.role}</span>
          </div>
        </div>
        <button id="sidebarLogoutBtn" class="btn btn-sm btn-outline-danger p-1 rounded-circle" title="Sign Out" style="width: 32px; height: 32px;">
          <i class="bi bi-box-arrow-right"></i>
        </button>
      </div>
    </div>
  `;
  appLayout.appendChild(sidebar);

  // Main Area
  const mainArea = document.createElement('div');
  mainArea.className = 'app-main-area';

  const header = document.createElement('header');
  header.className = 'app-header';
  header.innerHTML = `
    <div class="header-left">
      <button class="sidebar-toggle-btn d-lg-none" id="sidebarToggleBtn" aria-label="Toggle navigation">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div class="header-breadcrumb">
        <span class="text-muted fw-normal d-none d-sm-inline">Admin Portal</span>
        <span class="text-muted d-none d-sm-inline"><i class="bi bi-chevron-right" style="font-size: 0.75rem;"></i></span>
        <span class="fw-bold">${currentPageTitle}</span>
      </div>
    </div>

    <div class="header-right">
      <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-2 py-1 small d-none d-md-inline-flex align-items-center" title="MySQL 8.0 & MongoDB Active">
        <i class="bi bi-circle-fill me-1" style="font-size: 0.5rem;"></i>
        <span>DBs Connected</span>
      </span>

      <a href="presentation.html" class="btn btn-sm btn-outline-primary d-none d-sm-inline-flex align-items-center rounded-pill px-2 py-1" title="Viva Presentation Slides">
        <i class="bi bi-easel2-fill me-1 text-warning"></i>
        <span class="small fw-semibold">Viva Deck</span>
      </a>

      <a href="notifications.html" class="btn btn-sm btn-light border position-relative rounded-circle p-2" title="Notifications" style="width: 38px; height: 38px;">
        <i class="bi bi-bell-fill text-secondary"></i>
        <span id="notif-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none" style="font-size: 0.65rem;">0</span>
      </a>

      <div class="dropdown">
        <button class="btn btn-sm btn-light border dropdown-toggle d-flex align-items-center rounded-pill px-2 py-1" type="button" id="headerUserMenu" data-bs-toggle="dropdown" aria-expanded="false">
          <div class="user-avatar-badge me-2" style="width: 28px; height: 28px; font-size: 0.75rem;">${userInitial}</div>
          <span class="d-none d-md-inline fw-semibold text-dark small me-1">${escapeHtml(user.full_name)}</span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-3 mt-2" aria-labelledby="headerUserMenu">
          <li><h6 class="dropdown-header text-dark fw-bold">${escapeHtml(user.full_name)}</h6></li>
          <li><span class="dropdown-item-text text-muted small">${escapeHtml(user.email)}</span></li>
          <li><span class="dropdown-item-text text-muted small">Role: <span class="badge bg-primary">${user.role}</span></span></li>
          <li><hr class="dropdown-divider"></li>
          <li>
            <button id="headerLogoutBtn" class="dropdown-item text-danger d-flex align-items-center">
              <i class="bi bi-box-arrow-right me-2"></i>Sign Out
            </button>
          </li>
        </ul>
      </div>
    </div>
  `;
  mainArea.appendChild(header);

  const contentBody = document.createElement('div');
  contentBody.className = 'app-content-body flex-grow-1';
  mainEl.parentNode.insertBefore(appLayout, mainEl);
  contentBody.appendChild(mainEl);
  mainArea.appendChild(contentBody);

  const footer = document.createElement('footer');
  footer.className = 'bg-white border-top py-3 text-muted small';
  footer.innerHTML = `
    <div class="container-fluid px-4 d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
      <div>
        <span>LEBMS Admin Operations · GTU BE05016031 Advanced Database Management System</span>
      </div>
      <div class="d-flex align-items-center gap-3">
        <span class="text-success"><i class="bi bi-shield-check me-1"></i>Enterprise 3-Tier</span>
        <a href="presentation.html" class="text-decoration-none text-primary fw-semibold">
          <i class="bi bi-easel2-fill me-1 text-warning"></i>Viva Slide Deck
        </a>
      </div>
    </div>
  `;
  mainArea.appendChild(footer);

  appLayout.appendChild(mainArea);

  const toggleBtn = document.getElementById('sidebarToggleBtn');
  const closeBtn = document.getElementById('sidebarCloseBtn');

  function openSidebar() {
    sidebar.classList.add('show');
    backdrop.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  function closeSidebar() {
    sidebar.classList.remove('show');
    backdrop.classList.remove('show');
    document.body.style.overflow = '';
  }

  toggleBtn?.addEventListener('click', openSidebar);
  closeBtn?.addEventListener('click', closeSidebar);
  backdrop?.addEventListener('click', closeSidebar);

  const handleLogout = async () => {
    try {
      await api.post('/api/auth/logout');
      window.location.href = '/login.html';
    } catch (e) {
      window.location.href = '/login.html';
    }
  };

  document.getElementById('sidebarLogoutBtn')?.addEventListener('click', handleLogout);
  document.getElementById('headerLogoutBtn')?.addEventListener('click', handleLogout);
}

// Fetch unread notifications
async function fetchUnreadNotificationsCount() {
  try {
    const res = await api.get('/api/notifications');
    const badge = document.getElementById('notif-badge');
    if (!badge || !res.data) return;

    const unread = res.data.filter(n => !n.is_read).length;
    if (unread > 0) {
      badge.textContent = unread > 99 ? '99+' : unread;
      badge.classList.remove('d-none');
    } else {
      badge.classList.add('d-none');
    }
  } catch (err) {
    // Fail silently
  }
}
