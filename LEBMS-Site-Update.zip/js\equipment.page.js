// public/js/equipment.page.js: Equipment Table, Search, Filters, and CRUD Logic
let currentPage = 1;
const limit = 10;
let categoriesList = [];
let labsList = [];

document.addEventListener('DOMContentLoaded', async () => {
  await loadFilterOptions();
  setupEventListeners();
  loadEquipment(1);
});

async function loadFilterOptions() {
  try {
    const [catRes, labRes] = await Promise.all([
      api.get('/api/categories'),
      api.get('/api/labs')
    ]);
    categoriesList = catRes.data || [];
    labsList = labRes.data || [];

    // Populate category dropdown
    const catSelect = document.getElementById('categoryFilter');
    const mCatSelect = document.getElementById('mCategory');
    categoriesList.forEach(c => {
      catSelect.insertAdjacentHTML('beforeend', `<option value="${c.category_id}">${escapeHtml(c.category_name)}</option>`);
      mCatSelect.insertAdjacentHTML('beforeend', `<option value="${c.category_id}">${escapeHtml(c.category_name)}</option>`);
    });

    // Populate lab dropdown
    const labSelect = document.getElementById('labFilter');
    const mLabSelect = document.getElementById('mLab');
    labsList.forEach(l => {
      labSelect.insertAdjacentHTML('beforeend', `<option value="${l.lab_id}">${escapeHtml(l.lab_name)} (${l.lab_code})</option>`);
      mLabSelect.insertAdjacentHTML('beforeend', `<option value="${l.lab_id}">${escapeHtml(l.lab_name)}</option>`);
    });
  } catch (err) {
    console.error('Error loading filters:', err);
  }
}

function setupEventListeners() {
  // Debounced search
  let debounceTimer;
  document.getElementById('searchInput').addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => loadEquipment(1), 300);
  });

  document.getElementById('categoryFilter').addEventListener('change', () => loadEquipment(1));
  document.getElementById('labFilter').addEventListener('change', () => loadEquipment(1));
  document.getElementById('availFilter').addEventListener('change', () => loadEquipment(1));
  document.getElementById('statusFilter').addEventListener('change', () => loadEquipment(1));

  document.getElementById('resetFiltersBtn').addEventListener('click', () => {
    document.getElementById('searchInput').value = '';
    document.getElementById('categoryFilter').value = '';
    document.getElementById('labFilter').value = '';
    document.getElementById('availFilter').value = '';
    document.getElementById('statusFilter').value = '';
    loadEquipment(1);
  });

  // Modal open for add
  document.getElementById('addEquipBtn')?.addEventListener('click', () => {
    document.getElementById('equipForm').reset();
    document.getElementById('editEquipId').value = '';
    document.getElementById('mCode').disabled = false;
    document.getElementById('equipModalLabel').textContent = 'Add New Equipment';
  });

  // Form submit
  document.getElementById('equipForm').addEventListener('submit', handleFormSubmit);
}

async function loadEquipment(page = 1) {
  currentPage = page;
  const tbody = document.getElementById('equipTableBody');
  tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm text-primary me-2"></div>Loading equipment...</td></tr>`;

  const params = {
    page,
    limit,
    q: document.getElementById('searchInput').value.trim(),
    categoryId: document.getElementById('categoryFilter').value,
    labId: document.getElementById('labFilter').value,
    availability: document.getElementById('availFilter').value,
    status: document.getElementById('statusFilter').value
  };

  try {
    const res = await api.get('/api/equipment', params);
    const { items, total, totalPages } = res.data;

    // Show staff action buttons if user is ADMIN or STAFF
    const user = window.currentUser;
    if (user && ['ADMIN', 'STAFF'].includes(user.role)) {
      document.getElementById('staffActions')?.classList.remove('d-none');
    }

    if (!items || items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-muted"><i class="bi bi-inbox fs-3 d-block mb-1"></i>No equipment found matching criteria.</td></tr>`;
      document.getElementById('paginationInfo').textContent = '0 items';
      document.getElementById('paginationControls').innerHTML = '';
      return;
    }

    let rowsHtml = '';
    for (const eq of items) {
      const isAvailable = eq.available_quantity > 0 && eq.status === 'ACTIVE';
      const stockBadge = isAvailable
        ? `<span class="badge bg-success-subtle text-success fw-bold">${eq.available_quantity} / ${eq.total_quantity}</span>`
        : `<span class="badge bg-danger-subtle text-danger fw-bold">${eq.available_quantity} / ${eq.total_quantity}</span>`;

      let actionButtons = '';

      // Faculty/Student Book button
      if (user && ['FACULTY', 'STUDENT'].includes(user.role)) {
        if (isAvailable) {
          actionButtons += `<a href="book.html?equipmentId=${eq.equipment_id}" class="btn btn-sm btn-outline-primary me-1"><i class="bi bi-calendar-check me-1"></i>Book</a>`;
        } else {
          actionButtons += `<button class="btn btn-sm btn-secondary me-1" disabled title="Not available">Unavailable</button>`;
        }
      }

      // Admin/Staff Edit & Delete
      if (user && ['ADMIN', 'STAFF'].includes(user.role)) {
        actionButtons += `
          <button class="btn btn-sm btn-outline-secondary me-1 edit-btn" data-id="${eq.equipment_id}" title="Edit"><i class="bi bi-pencil"></i></button>
          <button class="btn btn-sm btn-outline-danger delete-btn" data-id="${eq.equipment_id}" title="Delete"><i class="bi bi-trash"></i></button>
        `;
      }

      rowsHtml += `
        <tr>
          <td><span class="badge bg-light text-dark border font-monospace">${escapeHtml(eq.equipment_code)}</span></td>
          <td>
            <div class="fw-semibold text-dark">${escapeHtml(eq.equipment_name)}</div>
            <div class="small text-muted text-truncate" style="max-width: 280px;">${escapeHtml(eq.description || 'No description provided')}</div>
          </td>
          <td><span class="badge bg-light text-secondary border">${escapeHtml(eq.category_name)}</span></td>
          <td>${escapeHtml(eq.lab_name)}</td>
          <td class="text-center">${stockBadge}</td>
          <td>${renderStatusBadge(eq.status)}</td>
          <td class="font-monospace">${formatCurrency(eq.cost)}</td>
          <td class="text-end text-nowrap">${actionButtons}</td>
        </tr>
      `;
    }

    tbody.innerHTML = rowsHtml;

    // Bind edit and delete handlers
    tbody.querySelectorAll('.edit-btn').forEach(btn => {
      btn.addEventListener('click', () => openEditModal(btn.getAttribute('data-id')));
    });
    tbody.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', () => handleDelete(btn.getAttribute('data-id')));
    });

    const startItem = (page - 1) * limit + 1;
    const endItem = Math.min(page * limit, total);
    document.getElementById('paginationInfo').textContent = `Showing ${startItem}-${endItem} of ${total} equipment models`;
    renderPagination('paginationControls', { page, totalPages }, (newPage) => loadEquipment(newPage));
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-danger"><i class="bi bi-exclamation-triangle fs-3 d-block mb-1"></i>Error loading catalog: ${escapeHtml(err.message)}</td></tr>`;
  }
}

async function openEditModal(equipId) {
  try {
    const res = await api.get(`/api/equipment/${equipId}`);
    const eq = res.data;

    document.getElementById('editEquipId').value = eq.equipment_id;
    document.getElementById('mCode').value = eq.equipment_code;
    document.getElementById('mCode').disabled = true; // Code cannot be altered
    document.getElementById('mName').value = eq.equipment_name;
    document.getElementById('mCategory').value = eq.category_id;
    document.getElementById('mLab').value = eq.lab_id;
    document.getElementById('mTotalQty').value = eq.total_quantity;
    document.getElementById('mCost').value = eq.cost || '';
    document.getElementById('mDate').value = eq.purchase_date ? eq.purchase_date.split('T')[0] : '';
    document.getElementById('mDesc').value = eq.description || '';

    document.getElementById('equipModalLabel').textContent = `Edit Equipment (${eq.equipment_code})`;
    const modalEl = document.getElementById('equipModal');
    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
    modal.show();
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function handleFormSubmit(e) {
  e.preventDefault();
  const equipId = document.getElementById('editEquipId').value;
  const isEdit = !!equipId;

  const payload = {
    equipment_code: document.getElementById('mCode').value.trim(),
    equipment_name: document.getElementById('mName').value.trim(),
    category_id: parseInt(document.getElementById('mCategory').value, 10),
    lab_id: parseInt(document.getElementById('mLab').value, 10),
    total_quantity: parseInt(document.getElementById('mTotalQty').value, 10),
    cost: parseFloat(document.getElementById('mCost').value) || 0,
    purchase_date: document.getElementById('mDate').value || null,
    description: document.getElementById('mDesc').value.trim() || null
  };

  try {
    if (isEdit) {
      await api.put(`/api/equipment/${equipId}`, payload);
      showToast('Equipment updated successfully', 'success');
    } else {
      await api.post('/api/equipment', payload);
      showToast('Equipment added to catalog', 'success');
    }

    const modalEl = document.getElementById('equipModal');
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
    loadEquipment(currentPage);
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function handleDelete(equipId) {
  if (!confirm(`Are you sure you want to delete this equipment item? This action verifies foreign key referential integrity.`)) return;

  try {
    await api.delete(`/api/equipment/${equipId}`);
    showToast('Equipment deleted successfully', 'success');
    loadEquipment(currentPage);
  } catch (err) {
    showToast(err.message, 'danger');
  }
}
