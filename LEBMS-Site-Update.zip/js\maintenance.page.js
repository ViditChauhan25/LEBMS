// public/js/maintenance.page.js: Maintenance Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout({ requiredRoles: ['ADMIN', 'STAFF'] });
  if (!user) return;

  let currentPage = 1;
  const limit = 10;
  let scheduleModalInst = null;
  let completeModalInst = null;

  if (window.bootstrap) {
    const sEl = document.getElementById('scheduleModal');
    if (sEl) scheduleModalInst = new bootstrap.Modal(sEl);
    const cEl = document.getElementById('completeModal');
    if (cEl) completeModalInst = new bootstrap.Modal(cEl);
  }

  // Populate equipment dropdown
  async function loadEquipmentOptions() {
    try {
      const res = await api.get('/api/equipment?limit=200');
      const select = document.getElementById('maintEquipSelect');
      if (!select) return;
      select.innerHTML = '<option value="">Select Equipment...</option>';
      const items = res.data && res.data.equipment ? res.data.equipment : (res.data || []);
      items.forEach(eq => {
        const opt = document.createElement('option');
        opt.value = eq.equipment_id;
        opt.textContent = `${eq.equipment_code} - ${eq.equipment_name} (${eq.lab_code || ''} [${eq.status}])`;
        select.appendChild(opt);
      });
    } catch (err) {
      console.error('Failed to load equipment options:', err);
    }
  }

  // Set default scheduled date to today
  const schedDateInput = document.getElementById('maintSchedDate');
  if (schedDateInput) {
    schedDateInput.value = new Date().toISOString().split('T')[0];
  }

  async function loadMaintenance(page = 1) {
    currentPage = page;
    const status = document.getElementById('statusFilter').value;
    const tbody = document.getElementById('maintTableBody');
    tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading records...</td></tr>';

    try {
      const params = { page: currentPage, limit };
      if (status) params.status = status;
      const res = await api.get('/api/maintenance', params);
      const data = res.data || {};
      const items = data.records || [];
      const pagination = data.pagination || { total: items.length, page: 1, totalPages: 1 };

      if (items.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted">No maintenance records found.</td></tr>';
        document.getElementById('paginationInfo').textContent = 'Showing 0 of 0 items';
        document.getElementById('paginationControls').innerHTML = '';
        return;
      }

      tbody.innerHTML = items.map(m => {
        let badgeClass = 'badge-warning';
        if (m.status === 'IN_PROGRESS') badgeClass = 'badge-primary';
        if (m.status === 'COMPLETED') badgeClass = 'badge-success';

        let actionHtml = '';
        if (m.status === 'SCHEDULED') {
          actionHtml = `
            <button class="btn btn-sm btn-outline-primary me-1 start-btn" data-id="${m.maintenance_id}">
              <i class="bi bi-play-circle me-1"></i>Start
            </button>
            <button class="btn btn-sm btn-success comp-btn" data-id="${m.maintenance_id}">
              <i class="bi bi-check2-circle me-1"></i>Complete
            </button>
          `;
        } else if (m.status === 'IN_PROGRESS') {
          actionHtml = `
            <button class="btn btn-sm btn-success comp-btn" data-id="${m.maintenance_id}">
              <i class="bi bi-check2-circle me-1"></i>Complete
            </button>
          `;
        } else {
          actionHtml = `<span class="badge bg-secondary"><i class="bi bi-check-all me-1"></i>Archived</span>`;
        }

        return `
          <tr>
            <td class="fw-bold">#${m.maintenance_id}</td>
            <td>
              <div class="fw-semibold">${escapeHtml(m.equipment_name || 'Equipment #' + m.equipment_id)}</div>
              <small class="text-muted font-monospace">${escapeHtml(m.equipment_code || '')}</small>
            </td>
            <td><span class="badge bg-light text-dark border">${escapeHtml(m.maintenance_type)}</span></td>
            <td><small class="text-secondary">${escapeHtml(m.description || '')}</small></td>
            <td><small>${escapeHtml(m.scheduled_date || '-')}</small></td>
            <td><small>${escapeHtml(m.completed_date || '-')}</small></td>
            <td class="font-monospace">₹${parseFloat(m.cost || 0).toFixed(2)}</td>
            <td><span class="badge ${badgeClass}">${escapeHtml(m.status)}</span></td>
            <td class="text-end text-nowrap">${actionHtml}</td>
          </tr>
        `;
      }).join('');

      renderPagination(
        'paginationControls',
        'paginationInfo',
        pagination,
        (p) => loadMaintenance(p)
      );

      // Attach button listeners
      document.querySelectorAll('.start-btn').forEach(btn => {
        btn.addEventListener('click', () => startMaintenance(btn.dataset.id));
      });
      document.querySelectorAll('.comp-btn').forEach(btn => {
        btn.addEventListener('click', () => openCompleteModal(btn.dataset.id));
      });
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="9" class="text-center py-4 text-danger"><i class="bi bi-exclamation-triangle me-1"></i>Failed to load maintenance records: ${escapeHtml(err.message)}</td></tr>`;
    }
  }

  async function startMaintenance(id) {
    if (!confirm(`Mark maintenance #${id} as IN PROGRESS? This will mark equipment UNDER_MAINTENANCE.`)) return;
    try {
      await api.patch(`/api/maintenance/${id}/status`, { status: 'IN_PROGRESS' });
      showToast('Maintenance started. Equipment status updated.', 'success');
      loadMaintenance(currentPage);
    } catch (err) {
      showToast(err.message, 'danger');
    }
  }

  function openCompleteModal(id) {
    document.getElementById('compMaintId').value = id;
    document.getElementById('compCost').value = '0.00';
    document.getElementById('compTags').value = 'calibrated, verified, bench-tested';
    document.getElementById('compNotes').value = '';
    document.getElementById('partName').value = '';
    document.getElementById('partQty').value = '';
    document.getElementById('partCost').value = '';
    if (completeModalInst) completeModalInst.show();
  }

  // Handle Complete Form
  const compForm = document.getElementById('completeForm');
  if (compForm) {
    compForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('compMaintId').value;
      const cost = parseFloat(document.getElementById('compCost').value) || 0;
      const notes = document.getElementById('compNotes').value.trim();
      const tagsRaw = document.getElementById('compTags').value;
      const tags = tagsRaw.split(',').map(t => t.trim()).filter(Boolean);

      const checklist = [];
      if (document.getElementById('chk1')?.checked) checklist.push('Physical chassis, grounding pin & port inspection');
      if (document.getElementById('chk2')?.checked) checklist.push('Internal power supply voltage ripple measurement');
      if (document.getElementById('chk3')?.checked) checklist.push('Operational calibration against lab reference benchmark');

      const parts = [];
      const pName = document.getElementById('partName')?.value.trim();
      const pQty = parseInt(document.getElementById('partQty')?.value, 10);
      const pCost = parseFloat(document.getElementById('partCost')?.value);
      if (pName) {
        parts.push({
          name: pName,
          quantity: isNaN(pQty) ? 1 : pQty,
          unit_cost: isNaN(pCost) ? 0 : pCost
        });
      }

      try {
        await api.patch(`/api/maintenance/${id}/status`, {
          status: 'COMPLETED',
          cost,
          technician_notes: notes,
          checklist,
          parts_replaced: parts,
          tags
        });
        showToast('Maintenance completed! MongoDB log created and equipment status restored.', 'success');
        if (completeModalInst) completeModalInst.hide();
        loadMaintenance(currentPage);
      } catch (err) {
        showToast(err.message, 'danger');
      }
    });
  }

  // Handle Schedule Form
  const schedForm = document.getElementById('scheduleForm');
  if (schedForm) {
    schedForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const payload = {
        equipment_id: parseInt(document.getElementById('maintEquipSelect').value, 10),
        maintenance_type: document.getElementById('maintType').value,
        scheduled_date: document.getElementById('maintSchedDate').value,
        status: document.getElementById('maintInitStatus').value,
        description: document.getElementById('maintDesc').value.trim()
      };

      try {
        await api.post('/api/maintenance', payload);
        showToast('Maintenance job scheduled successfully.', 'success');
        schedForm.reset();
        if (scheduleModalInst) scheduleModalInst.hide();
        loadMaintenance(1);
      } catch (err) {
        showToast(err.message, 'danger');
      }
    });
  }

  document.getElementById('statusFilter')?.addEventListener('change', () => loadMaintenance(1));
  document.getElementById('refreshBtn')?.addEventListener('click', () => loadMaintenance(currentPage));

  await loadEquipmentOptions();
  await loadMaintenance(1);
});
