// public/js/showcase.page.js: ADBMS Curriculum Showcase Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout({ requiredRoles: ['ADMIN', 'STAFF'] });
  if (!user) return;

  const isAdmin = user.role === 'ADMIN';

  // 1. ACID Rollback Demo
  document.getElementById('runRollbackBtn')?.addEventListener('click', async () => {
    if (!isAdmin) {
      showToast('Admin privileges required to run raw rollback injection.', 'warning');
      return;
    }

    const box = document.getElementById('rollbackResult');
    box.innerHTML = '<div class="spinner-border spinner-border-sm me-2 text-danger"></div>Simulating crash inside transactional boundary...';

    try {
      const res = await api.post('/api/showcase/rollback');
      const d = res.data || {};
      box.innerHTML = `
        <div class="text-success fw-bold mb-2">
          <i class="bi bi-check-circle-fill me-1"></i>ACID ATOMICITY VERIFIED: ALL-OR-NOTHING RESTORATION
        </div>
        <div class="mb-1"><span class="text-muted">1. Baseline Available Units:</span> <strong class="text-primary">${d.before}</strong></div>
        <div class="mb-1"><span class="text-muted">2. Inside Transaction (Pending Commit):</span> <strong class="text-warning">${d.inside}</strong></div>
        <div class="mb-1"><span class="text-muted">3. Injected Exception:</span> <span class="text-danger">${escapeHtml(d.injectedError || 'Simulated failure')}</span></div>
        <div class="mb-1"><span class="text-muted">4. Recovery Action:</span> <span class="badge bg-danger">DB.ROLLBACK() EXECUTED</span></div>
        <div class="mb-1"><span class="text-muted">5. Post-Rollback Verified Units:</span> <strong class="text-success">${d.after}</strong> (Unchanged!)</div>
        <div class="mt-2 text-muted border-top pt-1 small">
          MongoDB audit log recorded: <code>TX_ROLLBACK</code> event with incident trace.
        </div>
      `;
    } catch (err) {
      box.innerHTML = `<span class="text-danger">Rollback demo failed: ${escapeHtml(err.message)}</span>`;
    }
  });

  // 2. Concurrency Race Demo
  document.getElementById('runConcurrencyBtn')?.addEventListener('click', async () => {
    if (!isAdmin) {
      showToast('Admin privileges required to run concurrency demo.', 'warning');
      return;
    }

    const box = document.getElementById('concurrencyResult');
    box.innerHTML = '<div class="spinner-border spinner-border-sm me-2 text-warning"></div>Launching parallel transactional race (Process A vs Process B)...';

    try {
      const res = await api.post('/api/showcase/concurrency');
      const d = res.data || {};
      const attempts = d.attempts || [];

      const attemptsHtml = attempts.map(a => {
        const badge = a.success ? 'bg-success' : 'bg-danger';
        const icon = a.success ? 'bi-check-circle' : 'bi-x-circle';
        return `
          <div class="card p-2 mb-2 border ${a.success ? 'border-success' : 'border-danger'} bg-white">
            <div class="d-flex justify-content-between align-items-center">
              <strong>${escapeHtml(a.attempt)}</strong>
              <span class="badge ${badge}"><i class="bi ${icon} me-1"></i>${a.success ? 'SUCCESS' : 'FAILED (409)'}</span>
            </div>
            <div class="small text-muted mt-1">Duration: ${a.durationMs}ms | Message: ${escapeHtml(a.error || 'Issued unit booked')}</div>
          </div>
        `;
      }).join('');

      box.innerHTML = `
        <div class="text-primary fw-bold mb-2">
          <i class="bi bi-shield-lock-fill me-1"></i>TWO-PHASE ROW-LEVEL LOCKING VERIFIED
        </div>
        ${attemptsHtml}
        <div class="mt-2 text-dark small border-top pt-1">
          <strong>Theoretical Analysis:</strong> ${escapeHtml(d.analysis?.outcome || 'Lock serialized access cleanly.')}
        </div>
      `;
    } catch (err) {
      box.innerHTML = `<span class="text-danger">Concurrency demo failed: ${escapeHtml(err.message)}</span>`;
    }
  });

  // 3. SQL Showcase
  async function loadSqlShowcase() {
    const name = document.getElementById('sqlSelect').value;
    const txtBox = document.getElementById('sqlText');
    const thead = document.getElementById('sqlTableHead');
    const tbody = document.getElementById('sqlTableBody');

    txtBox.textContent = 'Loading query definition...';
    tbody.innerHTML = '<tr><td class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Executing SQL...</td></tr>';

    try {
      const res = await api.get(`/api/showcase/sql/${name}`);
      const d = res.data || {};
      txtBox.textContent = d.query || '';

      const rows = d.result || [];
      if (rows.length === 0) {
        thead.innerHTML = '<tr><th>Result</th></tr>';
        tbody.innerHTML = '<tr><td class="text-center py-4 text-muted">Query returned 0 rows.</td></tr>';
        return;
      }

      const cols = Object.keys(rows[0]);
      thead.innerHTML = `<tr>${cols.map(c => `<th>${escapeHtml(c)}</th>`).join('')}</tr>`;
      tbody.innerHTML = rows.map(r => `
        <tr>${cols.map(c => `<td><small>${escapeHtml(String(r[c] !== null ? r[c] : 'NULL'))}</small></td>`).join('')}</tr>
      `).join('');
    } catch (err) {
      txtBox.textContent = `Error: ${err.message}`;
      tbody.innerHTML = `<tr><td class="text-danger text-center py-4">${escapeHtml(err.message)}</td></tr>`;
    }
  }

  // 4. Mongo Showcase
  async function loadMongoShowcase() {
    const name = document.getElementById('mongoSelect').value;
    const txtBox = document.getElementById('mongoText');
    const outBox = document.getElementById('mongoOutput');

    txtBox.textContent = 'Loading pipeline definition...';
    outBox.textContent = 'Executing MongoDB aggregation...';

    try {
      const res = await api.get(`/api/showcase/mongo/${name}`);
      const d = res.data || {};
      txtBox.textContent = d.query || '';
      outBox.textContent = JSON.stringify(d.result, null, 2);
    } catch (err) {
      txtBox.textContent = `Error: ${err.message}`;
      outBox.textContent = `Failed: ${err.message}`;
    }
  }

  document.getElementById('runSqlBtn')?.addEventListener('click', loadSqlShowcase);
  document.getElementById('sqlSelect')?.addEventListener('change', loadSqlShowcase);

  document.getElementById('runMongoBtn')?.addEventListener('click', loadMongoShowcase);
  document.getElementById('mongoSelect')?.addEventListener('change', loadMongoShowcase);

  // Initialize first queries
  loadSqlShowcase();
  loadMongoShowcase();
});
