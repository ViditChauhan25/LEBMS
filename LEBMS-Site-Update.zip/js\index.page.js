// public/js/index.page.js: Dual Dashboard Logic (Admin View & Student/User Portal View)
let monthlyChart = null;
let maintChart = null;
let deptChart = null;
let topEquipChart = null;

document.addEventListener('DOMContentLoaded', async () => {
  try {
    let user = window.currentUser;
    if (!user) {
      const authRes = await api.get('/api/auth/me');
      user = authRes.data;
      window.currentUser = user;
    }

    if (['ADMIN', 'STAFF'].includes(user.role)) {
      initAdminDashboard();
    } else {
      initUserDashboard(user);
    }
  } catch (err) {
    console.error('Failed to initialize dashboard:', err);
  }
});

/* ============================================================
   ADMIN & STAFF DASHBOARD
   ============================================================ */
async function initAdminDashboard() {
  const adminView = document.getElementById('adminDashboardView');
  if (adminView) adminView.classList.remove('d-none');

  loadAdminData();
  document.getElementById('adminRefreshBtn')?.addEventListener('click', loadAdminData);
}

async function loadAdminData() {
  try {
    const kpisRes = await api.get('/api/dashboard/kpis').catch(e => {
      console.warn('KPI fetch fallback:', e);
      return { data: api._demoData?.kpis };
    });
    if (kpisRes && kpisRes.data) renderAdminKpis(kpisRes.data);
  } catch (err) {
    console.error('Failed to load admin KPIs:', err);
  }

  try {
    const chartsRes = await api.get('/api/dashboard/charts').catch(e => {
      console.warn('Charts fetch fallback:', e);
      return { data: api._demoData?.charts };
    });
    if (chartsRes && chartsRes.data) renderAdminCharts(chartsRes.data);
  } catch (err) {
    console.error('Failed to load admin charts:', err);
  }
}

function renderAdminKpis(kpis) {
  document.getElementById('kpi-total').textContent = kpis.totalEquipment;
  document.getElementById('kpi-available').textContent = kpis.availableUnits;
  document.getElementById('kpi-booked').textContent = kpis.bookedUnits;
  document.getElementById('kpi-maint').textContent = kpis.underMaintenance;
}

function formatMonthLabel(mStr) {
  if (!mStr) return '';
  const [year, month] = mStr.split('-');
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const mIndex = parseInt(month, 10) - 1;
  return `${monthNames[mIndex] || month} ${year}`;
}

function renderAdminCharts(data) {
  if (!data) return;
  const monthlyList = Array.isArray(data.monthlyBookings) ? data.monthlyBookings : (data.monthlyTrend || []);
  const maintList = Array.isArray(data.maintenanceSummary) ? data.maintenanceSummary : (data.maintenanceStatus || []);
  const deptList = Array.isArray(data.departmentUsage) ? data.departmentUsage : [];
  const topList = Array.isArray(data.mostUsedEquipment) ? data.mostUsedEquipment : [];

  // 1. Monthly Bookings Line Chart
  const monthlyEl = document.getElementById('monthlyChart');
  if (monthlyEl && monthlyList.length > 0) {
    const monthlyCtx = monthlyEl.getContext('2d');
    if (monthlyChart) {
      monthlyChart.destroy();
      monthlyChart = null;
    }
    monthlyChart = new Chart(monthlyCtx, {
      type: 'line',
      data: {
        labels: monthlyList.map(m => formatMonthLabel(m.month)),
        datasets: [{
          label: 'Completed Bookings',
          data: monthlyList.map(m => m.count),
          borderColor: '#4f46e5',
          backgroundColor: 'rgba(79, 70, 229, 0.12)',
          borderWidth: 2.5,
          tension: 0.35,
          fill: true,
          pointBackgroundColor: '#6366f1',
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 600 },
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              boxWidth: 12,
              font: { family: "'Plus Jakarta Sans', sans-serif", weight: '600' }
            }
          },
          tooltip: {
            backgroundColor: '#0f172a',
            titleFont: { family: "'Plus Jakarta Sans', sans-serif" },
            bodyFont: { family: "'Plus Jakarta Sans', sans-serif" },
            padding: 10,
            cornerRadius: 8
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { precision: 0, font: { family: "'Plus Jakarta Sans', sans-serif" } },
            grid: { color: 'rgba(226, 232, 240, 0.6)' }
          },
          x: {
            ticks: { font: { family: "'Plus Jakarta Sans', sans-serif" } },
            grid: { display: false }
          }
        }
      }
    });
  }

  // 2. Maintenance Doughnut Chart
  const maintEl = document.getElementById('maintChart');
  if (maintEl && maintList.length > 0) {
    const maintCtx = maintEl.getContext('2d');
    if (maintChart) maintChart.destroy();
    maintChart = new Chart(maintCtx, {
      type: 'doughnut',
      data: {
        labels: maintList.map(m => m.status),
        datasets: [{
          data: maintList.map(m => m.count),
          backgroundColor: ['#f59e0b', '#ef4444', '#10b981'],
          borderWidth: 2,
          borderColor: '#ffffff'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom' }
        }
      }
    });
  }

  // 3. Department-Wise Usage Bar Chart
  const deptEl = document.getElementById('deptChart');
  if (deptEl && deptList.length > 0) {
    const deptCtx = deptEl.getContext('2d');
    if (deptChart) deptChart.destroy();
    deptChart = new Chart(deptCtx, {
      type: 'bar',
      data: {
        labels: deptList.map(d => d.code || d.department),
        datasets: [{
          label: 'Bookings by Department',
          data: deptList.map(d => d.count),
          backgroundColor: '#0d9488',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: { beginAtZero: true, ticks: { precision: 0 } }
        }
      }
    });
  }

  // 4. Most Demanded Equipment Horizontal Bar Chart
  const topEl = document.getElementById('topEquipChart');
  if (topEl && topList.length > 0) {
    const topCtx = topEl.getContext('2d');
    if (topEquipChart) topEquipChart.destroy();
    topEquipChart = new Chart(topCtx, {
      type: 'bar',
      data: {
        labels: topList.map(e => (e.name || '').length > 20 ? (e.name || '').substring(0, 18) + '...' : (e.name || 'Equipment')),
        datasets: [{
          label: 'Times Issued',
          data: topList.map(e => e.count),
          backgroundColor: '#4f46e5',
          borderRadius: 6
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { beginAtZero: true, ticks: { precision: 0 } }
        }
      }
    });
  }
}

/* ============================================================
   STUDENT & USER PORTAL DASHBOARD
   ============================================================ */
async function initUserDashboard(user) {
  const userView = document.getElementById('userDashboardView');
  if (userView) userView.classList.remove('d-none');

  // Populate User Info
  document.getElementById('userStudentName').textContent = user.full_name || 'Student';
  if (user.enrollment_no) {
    document.getElementById('userEnrollmentBadge').textContent = `Enrollment: ${user.enrollment_no}`;
  } else {
    document.getElementById('userEnrollmentBadge').textContent = `Role: ${user.role}`;
  }

  // Load Department Name if possible
  try {
    const deptRes = await api.get('/api/departments');
    const myDept = deptRes.data?.find(d => d.department_id === user.department_id);
    if (myDept) {
      document.getElementById('userDeptBadge').textContent = `Department: ${myDept.department_name}`;
    }
  } catch (e) {}

  // Load User's Personal Bookings
  try {
    const bookingsRes = await api.get('/api/bookings/my', { limit: 50 });
    const bookings = bookingsRes.data?.items || (Array.isArray(bookingsRes.data) ? bookingsRes.data : []);

    // Calculate Personal Stats
    let activeCount = 0;
    let issuedCount = 0;
    let pendingCount = 0;
    let completedCount = 0;

    bookings.forEach(b => {
      const s = (b.status || '').toUpperCase();
      if (s === 'ISSUED') {
        issuedCount++;
        activeCount++;
      } else if (s === 'APPROVED') {
        activeCount++;
      } else if (s === 'REQUESTED' || s === 'PENDING') {
        pendingCount++;
      } else if (s === 'CLOSED' || s === 'RETURNED') {
        completedCount++;
      }
    });

    document.getElementById('userKpiActive').textContent = activeCount;
    document.getElementById('userKpiIssued').textContent = issuedCount;
    document.getElementById('userKpiPending').textContent = pendingCount;
    document.getElementById('userKpiCompleted').textContent = completedCount;

    // Render Recent Bookings Table
    const tbody = document.getElementById('userBookingsTable');
    if (bookings.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" class="text-center py-4 text-muted">
            <i class="bi bi-inbox fs-3 d-block mb-2 text-secondary"></i>
            No equipment bookings yet. <a href="book.html" class="fw-semibold">Reserve hardware now</a>
          </td>
        </tr>
      `;
    } else {
      const recent = bookings.slice(0, 5);
      tbody.innerHTML = recent.map(b => `
        <tr>
          <td><span class="badge bg-light text-dark border">#${b.booking_id}</span></td>
          <td class="fw-semibold text-primary">${escapeHtml(b.equipment_name || 'Equipment')}</td>
          <td><span class="small text-muted">${escapeHtml(b.lab_name || 'Lab')}</span></td>
          <td><span class="small text-dark">${formatDate(b.start_datetime)} &rarr; ${formatDate(b.end_datetime)}</span></td>
          <td><span class="badge ${getStatusBadgeClass(b.status)}">${b.status}</span></td>
        </tr>
      `).join('');
    }
  } catch (err) {
    console.error('Failed to load user bookings:', err);
    document.getElementById('userBookingsTable').innerHTML = `
      <tr><td colspan="5" class="text-center text-danger py-3">Failed to load booking history</td></tr>
    `;
  }
}
