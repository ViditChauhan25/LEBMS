// public/js/xml.page.js: XML & XPath Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout({ requiredRoles: ['ADMIN', 'STAFF'] });
  if (!user) return;

  // Validate Equipment XSD
  document.getElementById('validateEquipBtn')?.addEventListener('click', async () => {
    const resBox = document.getElementById('equipValResult');
    resBox.className = 'alert alert-info py-2 small mb-0';
    resBox.textContent = 'Validating equipment XML against equipment.xsd...';
    resBox.classList.remove('d-none');

    try {
      const res = await api.get('/api/xml/validate?doc=equipment');
      const data = res.data || {};
      if (data.valid) {
        resBox.className = 'alert alert-success py-2 small mb-0';
        resBox.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i><strong>Validation Succeeded:</strong> equipment XML is 100% compliant with <code>equipment.xsd</code> (0 errors).';
      } else {
        resBox.className = 'alert alert-danger py-2 small mb-0';
        resBox.innerHTML = `<i class="bi bi-exclamation-triangle-fill me-1"></i><strong>Validation Failed:</strong> ${escapeHtml(data.errors?.join('; ') || 'Schema errors detected.')}`;
      }
    } catch (err) {
      resBox.className = 'alert alert-danger py-2 small mb-0';
      resBox.innerHTML = `<i class="bi bi-x-circle-fill me-1"></i>Error: ${escapeHtml(err.message)}`;
    }
  });

  // Validate Bookings XSD
  document.getElementById('validateBookBtn')?.addEventListener('click', async () => {
    const resBox = document.getElementById('bookValResult');
    resBox.className = 'alert alert-info py-2 small mb-0';
    resBox.textContent = 'Validating bookings XML against bookings.xsd...';
    resBox.classList.remove('d-none');

    try {
      const res = await api.get('/api/xml/validate?doc=bookings');
      const data = res.data || {};
      if (data.valid) {
        resBox.className = 'alert alert-success py-2 small mb-0';
        resBox.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i><strong>Validation Succeeded:</strong> bookings XML is 100% compliant with <code>bookings.xsd</code> (0 errors).';
      } else {
        resBox.className = 'alert alert-danger py-2 small mb-0';
        resBox.innerHTML = `<i class="bi bi-exclamation-triangle-fill me-1"></i><strong>Validation Failed:</strong> ${escapeHtml(data.errors?.join('; ') || 'Schema errors detected.')}`;
      }
    } catch (err) {
      resBox.className = 'alert alert-danger py-2 small mb-0';
      resBox.innerHTML = `<i class="bi bi-x-circle-fill me-1"></i>Error: ${escapeHtml(err.message)}`;
    }
  });

  // Preset selector
  document.getElementById('xpathPresets')?.addEventListener('change', (e) => {
    const val = e.target.value;
    if (val) {
      document.getElementById('xpathExprInput').value = val;
      if (val.includes('booking')) {
        document.getElementById('xpathDocSelect').value = 'bookings';
      } else {
        document.getElementById('xpathDocSelect').value = 'equipment';
      }
    }
  });

  // Run XPath button
  document.getElementById('runXpathBtn')?.addEventListener('click', async () => {
    const doc = document.getElementById('xpathDocSelect').value;
    const expression = document.getElementById('xpathExprInput').value.trim();
    const outBox = document.getElementById('xpathOutput');
    const badge = document.getElementById('xpathMatchBadge');

    if (!expression) {
      showToast('Please enter an XPath expression.', 'warning');
      return;
    }

    outBox.textContent = 'Executing XPath evaluation...';
    badge.className = 'badge bg-secondary';
    badge.textContent = 'Evaluating...';

    try {
      const res = await api.post('/api/xml/xpath', { doc, expression });
      const data = res.data || {};
      const results = data.results !== undefined ? data.results : data;
      const count = Array.isArray(results) ? results.length : (typeof results === 'number' ? results : 1);

      badge.className = 'badge bg-success';
      badge.textContent = `Matches: ${count}`;

      let formatted = '';
      if (Array.isArray(results)) {
        if (results.length === 0) {
          formatted = 'Query returned 0 matching nodes.';
        } else {
          formatted = results.map((item, idx) => `[${idx + 1}] ${typeof item === 'object' ? JSON.stringify(item, null, 2) : item}`).join('\n');
        }
      } else {
        formatted = typeof results === 'object' ? JSON.stringify(results, null, 2) : String(results);
      }

      outBox.textContent = formatted;
    } catch (err) {
      badge.className = 'badge bg-danger';
      badge.textContent = 'Failed';
      outBox.textContent = `XPath Evaluation Error:\n${err.message}`;
    }
  });
});
