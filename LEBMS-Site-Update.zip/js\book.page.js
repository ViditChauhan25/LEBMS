// public/js/book.page.js: Booking Form Client Logic
let equipmentList = [];

document.addEventListener('DOMContentLoaded', async () => {
  await loadEquipmentList();
  prefillFromQueryParam();
  setupFormHandler();
});

async function loadEquipmentList() {
  try {
    const res = await api.get('/api/equipment', { limit: 50, status: 'ACTIVE' });
    equipmentList = res.data.items || [];

    const select = document.getElementById('equipSelect');
    equipmentList.forEach(eq => {
      select.insertAdjacentHTML('beforeend', `
        <option value="${eq.equipment_id}" data-total="${eq.total_quantity}" data-avail="${eq.available_quantity}" data-lab="${escapeHtml(eq.lab_name)}" data-cat="${escapeHtml(eq.category_name)}">
          ${escapeHtml(eq.equipment_name)} (${escapeHtml(eq.equipment_code)}) - Avail: ${eq.available_quantity}/${eq.total_quantity}
        </option>
      `);
    });

    select.addEventListener('change', updateEquipmentInfoBadge);
  } catch (err) {
    console.error('Failed to load equipment list:', err);
  }
}

function updateEquipmentInfoBadge() {
  const select = document.getElementById('equipSelect');
  const opt = select.options[select.selectedIndex];
  const badgeContainer = document.getElementById('equipInfoBadge');

  if (!opt.value) {
    badgeContainer.classList.add('d-none');
    return;
  }

  document.getElementById('infoLab').textContent = `Lab: ${opt.getAttribute('data-lab')}`;
  document.getElementById('infoCategory').textContent = `Category: ${opt.getAttribute('data-cat')}`;
  document.getElementById('infoStock').textContent = `In Stock: ${opt.getAttribute('data-avail')} of ${opt.getAttribute('data-total')} units`;

  const qtyInput = document.getElementById('bookQuantity');
  qtyInput.max = opt.getAttribute('data-total');
  badgeContainer.classList.remove('d-none');
}

function prefillFromQueryParam() {
  const urlParams = new URLSearchParams(window.location.search);
  const equipId = urlParams.get('equipmentId');
  if (equipId) {
    const select = document.getElementById('equipSelect');
    select.value = equipId;
    updateEquipmentInfoBadge();
  }

  // Set default start time tomorrow 09:00, end tomorrow 17:00
  const now = new Date();
  now.setDate(now.getDate() + 1);
  now.setHours(9, 0, 0, 0);

  const end = new Date(now);
  end.setHours(17, 0, 0, 0);

  const toInputVal = (d) => {
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  document.getElementById('startDatetime').value = toInputVal(now);
  document.getElementById('endDatetime').value = toInputVal(end);
}

function setupFormHandler() {
  document.getElementById('bookingForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const alertEl = document.getElementById('bookingAlert');
    const submitBtn = document.getElementById('submitBookingBtn');
    const spinner = document.getElementById('btnSpinner');

    alertEl.classList.add('d-none');

    const equipId = document.getElementById('equipSelect').value;
    const quantity = parseInt(document.getElementById('bookQuantity').value, 10);
    const startVal = document.getElementById('startDatetime').value;
    const endVal = document.getElementById('endDatetime').value;
    const purpose = document.getElementById('bookPurpose').value.trim();

    // Plain string conversion from YYYY-MM-DDTHH:mm to YYYY-MM-DD HH:mm:00 (Erratum E8)
    const formatSql = (v) => v.replace('T', ' ') + ':00';
    const startStr = formatSql(startVal);
    const endStr = formatSql(endVal);

    if (startVal >= endVal) {
      alertEl.textContent = 'End datetime must be strictly after start datetime.';
      alertEl.className = 'alert alert-danger py-2 mb-3';
      alertEl.classList.remove('d-none');
      return;
    }

    submitBtn.disabled = true;
    spinner.classList.remove('d-none');

    try {
      const res = await api.post('/api/bookings', {
        equipment_id: equipId,
        quantity,
        start_datetime: startStr,
        end_datetime: endStr,
        purpose
      });

      alertEl.innerHTML = `<strong>Booking Requested!</strong> Request #${res.data.booking_id} submitted for staff review.`;
      alertEl.className = 'alert alert-success py-2 mb-3';
      alertEl.classList.remove('d-none');

      showToast('Booking request submitted successfully!', 'success');
      setTimeout(() => {
        window.location.href = '/my-bookings.html';
      }, 1000);
    } catch (err) {
      alertEl.textContent = err.message || 'Booking submission failed';
      alertEl.className = 'alert alert-danger py-2 mb-3';
      alertEl.classList.remove('d-none');
    } finally {
      submitBtn.disabled = false;
      spinner.classList.add('d-none');
    }
  });
}
