// public/js/reports.page.js: System Reports Page Controller
document.addEventListener('DOMContentLoaded', async () => {
  const user = await initLayout({ requiredRoles: ['ADMIN', 'STAFF'] });
  if (!user) return;

  let currentPage = 1;
  const limit = 15;

  const reportNames = {
    equipment: 'Equipment Master Inventory',
    bookings: 'Bookings & Reservation Register',
    issues: 'Equipment Issue Register (Checkouts)',
    returns: 'Equipment Return Register (Checkins)',
    maintenance: 'Maintenance & Servicing Log',
    damage: 'Incident & Damage Reports',
    monthly: 'Monthly Utilization Summary (View: v_monthly_usage)'
  };

  async function loadReport(page = 1) {
    currentPage = page;
    const type = document.getElementById('reportTypeSelect').value;
    const from = document.getElementById('dateFrom').value;
    const to = document.getElementById('dateTo').value;

    document.getElementById('currentReportTitle').textContent = reportNames[type] || type;
    document.getElementById('reportSubtitle').textContent = `Filtering from: ${from || 'Earliest'} to: ${to || 'Latest'}`;

    const thead = document.getElementById('reportTableHead');
    const tbody = document.getElementById('reportTableBody');
    tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Generating report...</td></tr>';

    try {
      const params = { page: currentPage, limit };
      if (from) params.from = from;
      if (to) params.to = to;

      const res = await api.get(`/api/reports/${type}`, params);
      const data = res.data || {};
      const headers = data.headers || [];
      const rows = data.rows || [];
      const pagination = data.pagination || { total: rows.length, page: 1, totalPages: 1 };

      if (headers.length === 0) {
        thead.innerHTML = '<tr><th>No Data</th></tr>';
        tbody.innerHTML = '<tr><td class="text-center py-4 text-muted">No schema available for this report.</td></tr>';
        return;
      }

      // Render thead
      thead.innerHTML = `<tr>${headers.map(h => `<th>${escapeHtml(h.label)}</th>`).join('')}</tr>`;

      if (rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="${headers.length}" class="text-center py-4 text-muted">No records found for the selected criteria.</td></tr>`;
        document.getElementById('paginationInfo').textContent = 'Showing 0 of 0 items';
        document.getElementById('paginationControls').innerHTML = '';
        return;
      }

      // Render tbody
      tbody.innerHTML = rows.map(r => {
        return `<tr>${headers.map(h => {
          let val = r[h.key];
          if (val === null || val === undefined) val = '-';
          if (h.key === 'status') {
            let bClass = 'bg-secondary';
            if (val === 'APPROVED' || val === 'RETURNED' || val === 'RESOLVED' || val === 'ACTIVE') bClass = 'bg-success';
            if (val === 'PENDING' || val === 'SCHEDULED' || val === 'UNDER_REVIEW') bClass = 'bg-warning text-dark';
            if (val === 'REJECTED' || val === 'OVERDUE' || val === 'CANCELLED') bClass = 'bg-danger';
            if (val === 'ISSUED' || val === 'IN_PROGRESS' || val === 'UNDER_MAINTENANCE') bClass = 'bg-primary';
            return `<td><span class="badge ${bClass}">${escapeHtml(String(val))}</span></td>`;
          }
          if (typeof val === 'number') {
            return `<td class="font-monospace">${escapeHtml(String(val))}</td>`;
          }
          return `<td><small>${escapeHtml(String(val))}</small></td>`;
        }).join('')}</tr>`;
      }).join('');

      renderPagination(
        'paginationControls',
        'paginationInfo',
        pagination,
        (p) => loadReport(p)
      );
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="10" class="text-center py-4 text-danger"><i class="bi bi-exclamation-triangle me-1"></i>Failed to generate report: ${escapeHtml(err.message)}</td></tr>`;
    }
  }

  function exportCsv() {
    const type = document.getElementById('reportTypeSelect').value;
    const from = document.getElementById('dateFrom').value;
    const to = document.getElementById('dateTo').value;

    let url = `/api/reports/${type}?format=csv`;
    if (from) url += `&from=${encodeURIComponent(from)}`;
    if (to) url += `&to=${encodeURIComponent(to)}`;

    window.open(url, '_blank');
  }

  document.getElementById('runReportBtn')?.addEventListener('click', () => loadReport(1));
  document.getElementById('reportTypeSelect')?.addEventListener('change', () => loadReport(1));
  document.getElementById('exportCsvBtn')?.addEventListener('click', exportCsv);
  document.getElementById('refreshBtn')?.addEventListener('click', () => loadReport(currentPage));

  // Initial load
  await loadReport(1);
});
